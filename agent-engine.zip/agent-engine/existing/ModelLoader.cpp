// ModelLoader.cpp

#include "ModelLoader.h"

#include <stdexcept>

namespace agent_engine {
namespace existing {

ModelLoader::ModelLoader() : config_() {}
ModelLoader::ModelLoader(ModelConfig config) : config_(std::move(config)) {}

LoaderResponse ModelLoader::infer(
    const std::vector<LoaderMessage>& /*messages*/,
    const std::string& /*tools_json*/) {
  if (!scripted_.empty()) {
    LoaderResponse r = std::move(scripted_.front());
    scripted_.erase(scripted_.begin());
    return r;
  }
  // Default mock behaviour: return a benign "I cannot help" stop response so
  // the framework can be exercised end-to-end without a live model.
  LoaderResponse r;
  r.content = "[mock] no scripted response available.";
  r.finish_reason = "stop";
  return r;
}

}  // namespace existing
}  // namespace agent_engine
