// ModelConfig.h
//
// Pretend this file already existed in the project before the agent framework
// was added. It owns the LLM parameter surface (temperature, max tokens, model
// id, etc.) and is reused as-is by the agent framework via the IModelAdapter.
//
// Per spec section 11: "Inspect the existing model-loading and parameter-
// configuration files before implementation ... Preserve existing
// functionality."

#ifndef AGENT_ENGINE_EXISTING_MODEL_CONFIG_H
#define AGENT_ENGINE_EXISTING_MODEL_CONFIG_H

#include <string>

namespace agent_engine {
namespace existing {

/// LLM inference parameters. Owned by ModelConfig and consumed by ModelLoader.
struct ModelConfig {
  std::string model_id = "mock-gpt-mini";
  float temperature = 0.2f;
  int max_tokens = 1024;
  bool enable_tool_calls = true;

  // The original project would likely load these from a config file or env.
  ModelConfig() = default;
  ModelConfig(std::string id, float temp, int max_tok, bool tools)
      : model_id(std::move(id)), temperature(temp),
        max_tokens(max_tok), enable_tool_calls(tools) {}
};

}  // namespace existing
}  // namespace agent_engine

#endif  // AGENT_ENGINE_EXISTING_MODEL_CONFIG_H
