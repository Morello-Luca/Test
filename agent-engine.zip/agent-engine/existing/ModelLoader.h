// ModelLoader.h
//
// Pretend this is pre-existing project code that loads a model configuration
// and (in a real build) performs inference. The agent framework does NOT call
// ModelLoader directly; it goes through IModelAdapter.

#ifndef AGENT_ENGINE_EXISTING_MODEL_LOADER_H
#define AGENT_ENGINE_EXISTING_MODEL_LOADER_H

#include <memory>
#include <string>
#include <vector>

#include "ModelConfig.h"

namespace agent_engine {
namespace existing {

/// A single message in the existing project's chat format.
struct LoaderMessage {
  std::string role;     // "system" | "user" | "assistant" | "tool"
  std::string content;
};

/// A tool-call entry as produced/consumed by the existing model layer.
struct LoaderToolCall {
  std::string id;
  std::string name;
  std::string arguments_json;
};

/// Raw response from the existing model layer.
struct LoaderResponse {
  std::string content;
  std::vector<LoaderToolCall> tool_calls;
  std::string finish_reason;  // "stop" | "tool_use" | "length" | "error"
};

/// Loads a ModelConfig (from a hard-coded default in the mock case) and exposes
/// a synchronous "inference" entry point. The real project would delegate to
/// an actual provider SDK here.
class ModelLoader {
 public:
  ModelLoader();
  explicit ModelLoader(ModelConfig config);

  const ModelConfig& config() const { return config_; }

  /// Synchronous mock inference. In a real project this would call a provider.
  /// The agent framework never calls this directly.
  LoaderResponse infer(const std::vector<LoaderMessage>& messages,
                       const std::string& tools_json);

  /// Used by tests to seed scripted responses. The real project would not
  /// expose this; instead it would forward to a real model.
  void push_scripted_response(LoaderResponse r) {
    scripted_.push_back(std::move(r));
  }

 private:
  ModelConfig config_;
  std::vector<LoaderResponse> scripted_;
};

}  // namespace existing
}  // namespace agent_engine

#endif  // AGENT_ENGINE_EXISTING_MODEL_LOADER_H
