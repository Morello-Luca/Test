// DomainModels.h
//
// Shared domain types: UserRequest, TaskPlan, PlanTask.
// Spec §2.1: combine small data-only types where appropriate.
// Spec §3: these are the core models everyone in the framework depends on.

#ifndef AGENT_ENGINE_CORE_MODELS_DOMAIN_MODELS_H
#define AGENT_ENGINE_CORE_MODELS_DOMAIN_MODELS_H

#include <algorithm>
#include <map>
#include <memory>
#include <string>
#include <vector>
#include <chrono>

namespace agent_engine {

using TaskId = std::string;

enum class TaskStatus {
  Pending,
  Ready,        // dependencies satisfied, awaiting scheduler
  InProgress,
  AwaitingVerification,
  Passed,
  Failed,
  Blocked,
  Skipped,
  Cancelled,
};

const char* task_status_name(TaskStatus s);

struct UserRequest {
  std::string id;                 // unique request id (e.g., UUID-ish)
  std::string user_text;          // original user prompt
  std::string created_at_iso;     // ISO-8601 timestamp
  std::map<std::string, std::string> extra_context;  // free-form key/value
};

/// Lifecycle of a single acceptance criterion. Spec §1 / §7: criteria must
/// NOT be marked as completed before execution and verification. The
/// verifier is the only component that transitions them to Passed / Failed
/// / Blocked.
enum class CriterionStatus {
  Defined,    // declared in the plan, no execution yet
  Pending,    // task in progress; criterion being checked
  Passed,     // verifier confirmed
  Failed,     // verifier rejected with evidence of failure
  Blocked,    // cannot be evaluated (e.g., missing evidence)
  Skipped,    // optional criterion intentionally skipped
};

const char* criterion_status_name(CriterionStatus s);
char         criterion_status_mark(CriterionStatus s);  // for markdown checkbox

struct AcceptanceCriterion {
  std::string id;                 // unique within task
  std::string description;        // human-readable
  bool        required = true;    // optional "soft" criteria supported
  CriterionStatus status = CriterionStatus::Defined;
};

struct PlanTask {
  TaskId id;
  std::string title;
  std::string description;
  TaskStatus status = TaskStatus::Pending;

  std::vector<TaskId> dependencies;       // IDs that must complete first

  std::vector<AcceptanceCriterion> acceptance_criteria;

  // Bounded retry policy per spec §5. `max_retries` counts retries AFTER
  // the initial attempt, so the total allowed attempts for a task are
  // `max_retries + 1`. `attempts` counts every execution of the task
  // (initial + retries) and is bumped at the start of AgentLoop::run_task.
  int max_retries = 2;
  int attempts = 0;

  // Convenience accessors so call sites don't have to remember the
  // "attempts vs retries" bookkeeping rule.
  int retries_used() const { return attempts > 0 ? attempts - 1 : 0; }
  int retries_remaining() const { return std::max(0, max_retries - retries_used()); }
  bool can_retry() const { return retries_used() < max_retries; }

  // Tool calls + results collected during execution. Stored as raw JSON
  // strings to keep domain types free of provider-specific structures.
  struct ExecutedCall {
    std::string tool_call_id;
    std::string tool_name;
    std::string arguments_json;
    std::string result_json;
    bool        ok = false;
    std::string error;
  };
  std::vector<ExecutedCall> executed_calls;

  bool has_unverified_claim = false;  // model asserted success without proof

  // Populated by RecoveryManager::apply on RetryTask. The AgentLoop feeds
  // this into the next inference's context so the model sees why its
  // previous attempt was rejected and is asked to take a different action.
  // Spec §2: "Feed the failure context into the next permitted recovery
  // attempt. Avoid repeating an identical inference without new information
  // or a changed recovery strategy."
  std::string prior_failure_reason;
};

struct TaskPlan {
  // Plan identity
  std::string request_id;          // back-ref to UserRequest.id
  std::string plan_id;             // unique plan id
  int version = 0;                 // increments on every revision
  std::string created_at_iso;
  std::string updated_at_iso;

  // Plan body
  std::string overall_goal;
  std::vector<std::string> milestones;
  std::vector<PlanTask> tasks;
  std::vector<std::string> risks;
  std::vector<std::string> assumptions;
  std::vector<std::string> missing_info;     // ambiguities identified

  // Approval policy: spec §4.3. "Material plan changes after approval must
  // trigger an explicit policy decision about whether renewed approval is
  // necessary."
  enum class ApprovalPolicy {
    AutoApproveRevisions,    // tests / dev
    RequireReapprovalOnMaterialChange,
    AlwaysRequireReapproval,
  };
  ApprovalPolicy approval_policy =
      ApprovalPolicy::RequireReapprovalOnMaterialChange;

  // True once the user has approved this version.
  bool approved = false;

  // Findings discovered during execution (spec §9 findings.md).
  std::vector<std::string> findings;

  // Lookup helpers
  PlanTask* find_task(const TaskId& id);
  const PlanTask* find_task(const TaskId& id) const;

  // True if any task has changed in a way that (per policy) needs reapproval.
  // Used by WorkflowController + RecoveryManager to decide whether to bounce
  // back to AwaitingApproval after a mid-execution plan edit.
  bool is_material_change_since(int earlier_version) const;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_MODELS_DOMAIN_MODELS_H
