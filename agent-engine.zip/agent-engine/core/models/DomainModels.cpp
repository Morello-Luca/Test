// DomainModels.cpp
//
// Out-of-line definitions for PlanTask / TaskPlan helpers.

#include "DomainModels.h"

#include <algorithm>

namespace agent_engine {

const char* task_status_name(TaskStatus s) {
  switch (s) {
    case TaskStatus::Pending:               return "Pending";
    case TaskStatus::Ready:                  return "Ready";
    case TaskStatus::InProgress:             return "InProgress";
    case TaskStatus::AwaitingVerification:   return "AwaitingVerification";
    case TaskStatus::Passed:                 return "Passed";
    case TaskStatus::Failed:                 return "Failed";
    case TaskStatus::Blocked:                return "Blocked";
    case TaskStatus::Skipped:                return "Skipped";
    case TaskStatus::Cancelled:              return "Cancelled";
  }
  return "?";
}

const char* criterion_status_name(CriterionStatus s) {
  switch (s) {
    case CriterionStatus::Defined:  return "Defined";
    case CriterionStatus::Pending:   return "Pending";
    case CriterionStatus::Passed:    return "Passed";
    case CriterionStatus::Failed:    return "Failed";
    case CriterionStatus::Blocked:   return "Blocked";
    case CriterionStatus::Skipped:    return "Skipped";
  }
  return "?";
}

/// Markdown checkbox glyph. We use distinct marks so the rendered
/// task_plan.md cannot be misread as "all criteria are checked off" before
/// verification has occurred.
char criterion_status_mark(CriterionStatus s) {
  switch (s) {
    case CriterionStatus::Defined:  return ' ';   // [ ] not yet evaluated
    case CriterionStatus::Pending:   return '.';  // [.] in progress
    case CriterionStatus::Passed:    return 'x';  // [x] verified passed
    case CriterionStatus::Failed:     return '!';  // [!] failed verification
    case CriterionStatus::Blocked:    return 'B';  // [B] blocked
    case CriterionStatus::Skipped:     return '-';  // [-] skipped
  }
  return '?';
}

PlanTask* TaskPlan::find_task(const TaskId& id) {
  for (auto& t : tasks) if (t.id == id) return &t;
  return nullptr;
}

const PlanTask* TaskPlan::find_task(const TaskId& id) const {
  for (const auto& t : tasks) if (t.id == id) return &t;
  return nullptr;
}

bool TaskPlan::is_material_change_since(int earlier_version) const {
  // Any version bump that adds/removes tasks or changes dependencies counts
  // as material; descriptive edits (e.g., tightening wording) do not, and
  // are silently propagated under AutoApproveRevisions.
  if (version <= earlier_version) return false;
  // Trivial heuristic: if task count or dependency graph changed, treat as
  // material. A real impl would diff a snapshot; we keep this minimal per
  // "smallest architecture" guidance.
  return true;  // conservative: any version bump after approval is material
}

}  // namespace agent_engine
