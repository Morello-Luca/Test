// ToolExecutionTypes.cpp

#include "ToolExecutionTypes.h"

namespace agent_engine {

const char* workflow_event_kind_name(WorkflowEventKind k) {
  switch (k) {
    case WorkflowEventKind::WorkflowStateChanged:        return "WorkflowStateChanged";
    case WorkflowEventKind::PlanCreated:                  return "PlanCreated";
    case WorkflowEventKind::PlanRevised:                  return "PlanRevised";
    case WorkflowEventKind::PlanApproved:                 return "PlanApproved";
    case WorkflowEventKind::PlanRejected:                 return "PlanRejected";
    case WorkflowEventKind::ClarificationRequested:      return "ClarificationRequested";
    case WorkflowEventKind::TaskSelected:                 return "TaskSelected";
    case WorkflowEventKind::ModelInferenceStarted:        return "ModelInferenceStarted";
    case WorkflowEventKind::ModelInferenceFinished:       return "ModelInferenceFinished";
    case WorkflowEventKind::ToolDispatched:               return "ToolDispatched";
    case WorkflowEventKind::ToolResultObtained:           return "ToolResultObtained";
    case WorkflowEventKind::VerificationStarted:          return "VerificationStarted";
    case WorkflowEventKind::VerificationFinished:         return "VerificationFinished";
    case WorkflowEventKind::RecoveryStarted:              return "RecoveryStarted";
    case WorkflowEventKind::RecoveryFinished:              return "RecoveryFinished";
    case WorkflowEventKind::TaskBlocked:                  return "TaskBlocked";
    case WorkflowEventKind::TaskCompleted:                return "TaskCompleted";
    case WorkflowEventKind::TaskFailed:                   return "TaskFailed";
    case WorkflowEventKind::IterationLimitReached:        return "IterationLimitReached";
    case WorkflowEventKind::WorkflowCancelled:            return "WorkflowCancelled";
    case WorkflowEventKind::WorkflowCompleted:            return "WorkflowCompleted";
    case WorkflowEventKind::WorkflowFailed:               return "WorkflowFailed";
    case WorkflowEventKind::Note:                          return "Note";
  }
  return "?";
}

}  // namespace agent_engine
