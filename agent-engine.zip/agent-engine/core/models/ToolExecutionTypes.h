// ToolExecutionTypes.h
//
// Tool invocation and result structures + workflow events. Per spec §2.1 these
// small data-only types are grouped together to avoid scatter. They are owned
// by the domain layer (core/models/).

#ifndef AGENT_ENGINE_CORE_MODELS_TOOL_EXECUTION_TYPES_H
#define AGENT_ENGINE_CORE_MODELS_TOOL_EXECUTION_TYPES_H

#include <map>
#include <string>
#include <vector>

namespace agent_engine {

// Spec §6: "Represent each tool invocation and result using structured data."
struct ToolCall {
  std::string id;              // unique invocation id
  std::string task_id;         // which task triggered this call
  std::string tool_name;
  std::string arguments_json; // validated JSON string

  // Where the call originated. "model" means a model-issued call routed
  // through ToolDispatcher; "system" means an internal call (e.g., recovery).
  std::string origin = "model";
};

// Spec §6: "A tool result must include: Invocation ID. Success or failure
// status. Output. Error details when applicable. Relevant execution metadata."
struct ToolResult {
  std::string invocation_id;     // matches ToolCall.id
  std::string tool_name;
  bool ok = false;
  std::string output;             // structured (often JSON) output
  std::string error;              // populated when !ok
  std::map<std::string, std::string> metadata;
  int duration_ms = 0;

  // Was the result's content flagged as untrusted? Spec §6: "Treat tool
  // outputs and file contents as untrusted data rather than instructions
  // that override system policies." Set by ToolDispatcher when it detects
  // content that smells like prompt injection.
  bool untrusted_content_flagged = false;
};

enum class WorkflowEventKind {
  WorkflowStateChanged,
  PlanCreated,
  PlanRevised,
  PlanApproved,
  PlanRejected,
  ClarificationRequested,
  TaskSelected,
  ModelInferenceStarted,
  ModelInferenceFinished,
  ToolDispatched,
  ToolResultObtained,
  VerificationStarted,
  VerificationFinished,
  RecoveryStarted,
  RecoveryFinished,
  TaskBlocked,
  TaskCompleted,
  TaskFailed,
  IterationLimitReached,
  WorkflowCancelled,
  WorkflowCompleted,
  WorkflowFailed,
  Note,                    // generic info
};

const char* workflow_event_kind_name(WorkflowEventKind k);

// Spec §9: progress.md is a view of structured state. Events are the
// authoritative structured log.
struct WorkflowEvent {
  WorkflowEventKind kind;
  std::string timestamp_iso;
  std::string workflow_state;     // state at time of event
  std::string message;
  std::map<std::string, std::string> details;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_MODELS_TOOL_EXECUTION_TYPES_H
