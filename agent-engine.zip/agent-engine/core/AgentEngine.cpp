// AgentEngine.cpp

#include "AgentEngine.h"

#include <iostream>
#include <sstream>

namespace agent_engine {

namespace {

const int kMaxSteps = 1000;

}  // namespace

AgentEngine::AgentEngine(std::unique_ptr<IModelAdapter> adapter,
                          IPlanRepository& repo)
    : log_(),
      adapter_(std::move(adapter)),
      repo_(repo),
      registry_(),
      ra_(std::make_unique<RequestAnalyzer>()),
      ca_(std::make_unique<ContextAnalyzer>()),
      td_(std::make_unique<TaskDecomposer>()),
      pv_(std::make_unique<PlanValidator>()),
      coordinator_(std::make_unique<PlanCoordinator>(
          log_, std::move(ra_), std::move(ca_),
          std::move(td_), std::move(pv_))),
      verifier_(std::make_unique<ResultVerifier>(log_)),
      recovery_(std::make_unique<RecoveryManager>(log_, *verifier_)),
      dispatcher_(std::make_unique<ToolDispatcher>(registry_, log_)),
      scheduler_(std::make_unique<TaskScheduler>()),
      loop_(std::make_unique<AgentLoop>(
          *adapter_, registry_, *dispatcher_, *scheduler_, log_)),
      renderer_(std::make_unique<MarkdownRenderer>(log_)),
      controller_(log_) {}

// ---- User-facing operations ---------------------------------------------

std::string AgentEngine::submit_request(const UserRequest& req) {
  original_request_ = req;
  workflow_id_ = req.id;
  // Draft → Planning.
  controller_.transition_to(WorkflowState::Planning, "submit_request");
  // Produce a draft plan via PlanCoordinator.
  auto analysis = coordinator_->analyze_request(req);
  plan_ = coordinator_->produce_draft_plan(req);
  plan_.missing_info = analysis.missing_info;
  plan_.assumptions = analysis.assumptions;

  if (analysis.needs_clarification()) {
    controller_.transition_to(WorkflowState::AwaitingClarification,
                              "missing info identified");
    return workflow_id_;
  }
  // Validate; if invalid, stay in Planning and surface errors via event log.
  auto v = coordinator_->validate(plan_);
  if (!v.ok) {
    for (const auto& e : v.errors) {
      log_.log(WorkflowEventKind::Note, "Planning",
               "validation error: " + e);
    }
    return workflow_id_;  // stay in Planning
  }
  controller_.transition_to(WorkflowState::AwaitingApproval,
                            "plan ready for approval");
  return workflow_id_;
}

EditOutcome AgentEngine::edit_plan(const PlanEdit& edit) {
  return coordinator_->apply_edit(plan_, edit);
}

bool AgentEngine::approve_plan() {
  if (controller_.state() != WorkflowState::AwaitingApproval) return false;
  coordinator_->approve(plan_);
  return controller_.transition_to(WorkflowState::Executing,
                                     "plan approved");
}

const TaskPlan& AgentEngine::reject_plan_and_revise(const std::string& reason,
                                                       const std::string& note) {
  if (controller_.state() != WorkflowState::AwaitingApproval) {
    return plan_;
  }
  coordinator_->reject(plan_, reason);
  controller_.transition_to(WorkflowState::Planning,
                             "plan rejected; revising");
  plan_ = coordinator_->request_revision(plan_, original_request_, note);
  controller_.transition_to(WorkflowState::AwaitingApproval,
                            "revised plan ready");
  return plan_;
}

bool AgentEngine::answer_clarification(const std::string& answer) {
  if (controller_.state() != WorkflowState::AwaitingClarification) return false;
  // Fold the answer into extra_context and re-produce the plan.
  original_request_.extra_context["user_answer"] = answer;
  plan_ = coordinator_->produce_draft_plan(original_request_);
  controller_.transition_to(WorkflowState::Planning,
                             "clarification received; re-planning");
  controller_.transition_to(WorkflowState::AwaitingApproval,
                            "revised plan ready");
  return true;
}

// ---- step / run ---------------------------------------------------------

bool AgentEngine::step() {
  switch (controller_.state()) {
    case WorkflowState::Executing: {
      // Pick the next eligible task.
      auto next = scheduler_->next_eligible(plan_);
      if (!next.has_value()) {
        // Either blocked, complete, or stalled.
        // Spec §3: completion requires all tasks Passed + criteria Passed.
        // Spec §3: blocked/failed outcomes are distinct from completion.
        if (ProgressTracker::is_failed(plan_)) {
          controller_.transition_to(WorkflowState::Failed,
                                       "at least one task has Failed");
          return false;
        }
        if (ProgressTracker::is_blocked(plan_)) {
          controller_.transition_to(WorkflowState::Blocked,
                                       "no eligible task and at least one "
                                       "Blocked task exists");
          return false;
        }
        if (ProgressTracker::is_complete(plan_)) {
          controller_.transition_to(WorkflowState::Completed,
                                       "all tasks + criteria passed");
          return false;
        }
        // No failed/blocked task but also no eligible task and not
        // complete — stalled (e.g., a dependency cycle that the validator
        // missed at plan time, or all remaining tasks cancelled without
        // any completing).
        if (ProgressTracker::is_cancelled(plan_)) {
          controller_.transition_to(WorkflowState::Cancelled,
                                       "all tasks cancelled");
          return false;
        }
        controller_.transition_to(WorkflowState::Failed,
                                   "no eligible task and not complete; stalled");
        return false;
      }
      // Execute.
      auto outcome = loop_->run_task(plan_, next->id);
      switch (outcome) {
        case LoopOutcome::TaskAwaitingVerification:
          controller_.transition_to(WorkflowState::Verifying,
                                      "task awaiting verification");
          return true;
        case LoopOutcome::TaskFailed:
          // Hand off to recovery directly.
          controller_.transition_to(WorkflowState::Recovering,
                                      "task failed");
          return true;
        case LoopOutcome::TaskBlocked:
          controller_.transition_to(WorkflowState::Blocked,
                                      "task blocked");
          return true;
        case LoopOutcome::IterationLimitReached:
        case LoopOutcome::ToolCallLimitReached:
          controller_.transition_to(WorkflowState::Recovering,
                                      "limit reached");
          return true;
        case LoopOutcome::Cancelled:
          controller_.transition_to(WorkflowState::Cancelled,
                                      "cancelled");
          return false;
        case LoopOutcome::ClarificationNeeded:
          controller_.transition_to(WorkflowState::AwaitingClarification,
                                      "clarification needed mid-exec");
          return true;
      }
      return true;
    }
    case WorkflowState::Verifying: {
      // Find the task currently awaiting verification.
      PlanTask* t = nullptr;
      for (auto& task : plan_.tasks) {
        if (task.status == TaskStatus::AwaitingVerification) {
          t = &task; break;
        }
      }
      if (!t) {
        controller_.transition_to(WorkflowState::Executing,
                                   "no task to verify");
        return true;
      }
      auto vr = verifier_->verify(plan_, *t);
      // Spec §1: apply verification result to criterion statuses. This is
      // the ONLY place criteria transition out of Defined.
      apply_verification_to_task(*t, vr);
      if (vr.overall_passed) {
        t->status = TaskStatus::Passed;
        t->has_unverified_claim = false;
        t->prior_failure_reason.clear();
        log_.log(WorkflowEventKind::TaskCompleted, "Verifying",
                 t->id + " verified + passed");
        // Check workflow-level completion now (spec §3).
        if (ProgressTracker::is_complete(plan_)) {
          controller_.transition_to(WorkflowState::Completed,
                                      "all tasks + criteria passed");
          return false;
        }
        controller_.transition_to(WorkflowState::Executing,
                                   "task verified; continue");
        return true;
      }
      // Failure → recovery.
      log_.log(WorkflowEventKind::TaskFailed, "Verifying",
               t->id + " verification failed: " +
               (vr.cause.empty() ? "unspecified" : vr.cause));
      controller_.transition_to(WorkflowState::Recovering,
                                 "verification failed");
      return true;
    }
    case WorkflowState::Recovering: {
      // Find the task in failure / awaiting verification.
      PlanTask* t = nullptr;
      for (auto& task : plan_.tasks) {
        if (task.status == TaskStatus::AwaitingVerification ||
            task.status == TaskStatus::Failed ||
            task.status == TaskStatus::InProgress) {
          t = &task; break;
        }
      }
      if (!t) {
        controller_.transition_to(WorkflowState::Executing,
                                   "no task to recover");
        return true;
      }
      // The verifier may have already run for this task in the prior
      // Verifying step; we re-verify to get a fresh result to feed
      // into the recovery decision (with the same evidence).
      auto vr = verifier_->verify(plan_, *t);
      apply_verification_to_task(*t, vr);
      auto d = recovery_->diagnose(plan_, *t, vr);
      log_.log(WorkflowEventKind::RecoveryStarted, "Recovering",
               t->id + ": recovery decision=" +
               std::to_string(static_cast<int>(d.action)) +
               " reason=" + d.reason);
      recovery_->apply(plan_, *t, d);
      if (d.action == RecoveryAction::RevisePlan) {
        // Spec §4.3: bounce back to user. plan.approved was cleared by
        // RecoveryManager::apply.
        controller_.transition_to(WorkflowState::AwaitingApproval,
                                   "material plan change requires approval; "
                                   "approval invalidated");
        return false;  // Need user input; stop stepping.
      }
      if (d.action == RecoveryAction::BlockTask) {
        // Spec §3: blocked task → workflow Blocked (distinct from Failed
        // and from Completed).
        controller_.transition_to(WorkflowState::Blocked,
                                   "task blocked: " + d.reason);
        return false;  // Stuck until user intervention.
      }
      if (d.action == RecoveryAction::FailTask ||
          d.action == RecoveryAction::FailWorkflow) {
        // Spec §3: failed required task → workflow Failed.
        controller_.transition_to(WorkflowState::Failed,
                                   "task failed: " + d.reason);
        return false;
      }
      // RetryTask → continue execution.
      controller_.transition_to(WorkflowState::Executing,
                                 "recovery applied; retry scheduled");
      return true;
    }
    case WorkflowState::Blocked: {
      // Check if any task can be unblocked now (e.g., after user input).
      // For initial implementation, Blocked stays.
      return false;
    }
    case WorkflowState::AwaitingApproval:
    case WorkflowState::AwaitingClarification:
    case WorkflowState::Paused:
      // Need user input; stop stepping.
      return false;
    case WorkflowState::Completed:
    case WorkflowState::Cancelled:
    case WorkflowState::Failed:
    case WorkflowState::Draft:
    case WorkflowState::Planning:
      return false;
  }
  return false;
}

AgentEngine::RunResult AgentEngine::run() {
  int steps = 0;
  while (step() && steps++ < kMaxSteps) {
    // continue
  }
  switch (controller_.state()) {
    case WorkflowState::Completed:   return RunResult::Completed;
    case WorkflowState::Cancelled:   return RunResult::Cancelled;
    case WorkflowState::Failed:      return RunResult::Failed;
    case WorkflowState::Blocked:     return RunResult::Blocked;
    default:                          return RunResult::Stalled;
  }
}

void AgentEngine::cancel(const std::string& reason) {
  controller_.transition_to(WorkflowState::Cancelled, reason);
  for (auto& t : plan_.tasks) {
    if (t.status == TaskStatus::InProgress ||
        t.status == TaskStatus::Pending ||
        t.status == TaskStatus::Ready ||
        t.status == TaskStatus::AwaitingVerification) {
      t.status = TaskStatus::Cancelled;
    }
  }
  log_.log(WorkflowEventKind::WorkflowCancelled, "Cancelled", reason);
}

// ---- Inspection / artifacts --------------------------------------------

std::string AgentEngine::render_task_plan_md() const {
  return renderer_->render_task_plan(plan_);
}

std::string AgentEngine::render_findings_md() const {
  return renderer_->render_findings(plan_);
}

std::string AgentEngine::render_progress_md() const {
  auto next = ProgressTracker::next_action(controller_.state(), plan_);
  return renderer_->render_progress(plan_, next);
}

// ---- Resumability -------------------------------------------------------

void AgentEngine::checkpoint(const std::string& workflow_id) {
  // Log the checkpoint event BEFORE saving the snapshot so a resumed engine
  // sees it in the replayed event log.
  log_.log(WorkflowEventKind::Note,
           workflow_state_name(controller_.state()),
           "checkpointed " + workflow_id);
  WorkflowSnapshot snap;
  snap.workflow_id = workflow_id;
  snap.original_request = original_request_;
  snap.plan = plan_;
  snap.state = controller_.state();
  snap.events = log_.snapshot();
  snap.last_action_summary =
      ProgressTracker::next_action(controller_.state(), plan_);
  repo_.save(snap);
}

bool AgentEngine::resume(const std::string& workflow_id) {
  auto snap = repo_.load(workflow_id);
  if (!snap) return false;
  original_request_ = snap->original_request;
  plan_ = snap->plan;
  workflow_id_ = workflow_id;
  // Replay events into our log so progress.md reflects the prior run.
  for (const auto& e : snap->events) log_.append(e);
  // Transition directly to the snapshotted state via Draft (legal) if needed.
  if (controller_.state() != WorkflowState::Draft) {
    // Force reset; in tests we expect fresh engines.
    // Production code might use a private setter instead.
  }
  // For non-terminal states, transition to the snapshotted state via
  // legal transitions (Draft → Planning → ... → snap.state). Since the
  // state machine enforces transitions, we synthesize a path:
  if (snap->state == WorkflowState::Draft) {
    return true;  // already Draft
  }
  controller_.transition_to(WorkflowState::Planning, "resume: planning");
  if (snap->state == WorkflowState::Planning) return true;
  controller_.transition_to(WorkflowState::AwaitingApproval,
                             "resume: awaiting approval");
  if (snap->state == WorkflowState::AwaitingApproval) return true;
  // If snapshotted state is mid-execution, transition to Executing.
  if (snap->state == WorkflowState::Executing ||
      snap->state == WorkflowState::Verifying ||
      snap->state == WorkflowState::Recovering ||
      snap->state == WorkflowState::Paused) {
    controller_.transition_to(WorkflowState::Executing,
                                "resume: executing");
  }
  log_.log(WorkflowEventKind::Note,
           workflow_state_name(controller_.state()),
           "resumed " + workflow_id);
  return true;
}

}  // namespace agent_engine
