// ProgressTracker.h
//
// Spec §9: progress.md is a view of structured state. ProgressTracker holds
// the snapshot info needed to render that view + answer "what's next?".
//
// Spec §10: the InMemoryPlanRepository persists enough to reconstruct the
// workflow. ProgressTracker augments that with a derived "next action"
// string used by both progress.md and the workflow controller.

#ifndef AGENT_ENGINE_CORE_ARTIFACTS_PROGRESS_TRACKER_H
#define AGENT_ENGINE_CORE_ARTIFACTS_PROGRESS_TRACKER_H

#include "core/models/DomainModels.h"
#include "core/WorkflowState.h"

#include <string>

namespace agent_engine {

class ProgressTracker {
 public:
  /// Build the canonical "next action" string from the workflow state and
  /// plan. Used by MarkdownRenderer::render_progress.
  static std::string next_action(WorkflowState state, const TaskPlan& plan);

  /// True when the plan can be considered "complete" per spec §3 + §8:
  /// every task is Passed AND every required acceptance criterion is
  /// Passed. A workflow with any Blocked / Failed / Cancelled task is NOT
  /// complete.
  static bool is_complete(const TaskPlan& plan);

  /// True if any task is Blocked. Such a workflow cannot reach Completed
  /// without external intervention.
  static bool is_blocked(const TaskPlan& plan);

  /// True if any task is Failed. The workflow is failed and cannot
  /// complete.
  static bool is_failed(const TaskPlan& plan);

  /// True if any task is Cancelled. The workflow is cancelled.
  static bool is_cancelled(const TaskPlan& plan);
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_ARTIFACTS_PROGRESS_TRACKER_H
