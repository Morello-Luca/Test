// ProgressTracker.cpp

#include "ProgressTracker.h"

#include <sstream>
#include <unordered_set>

namespace agent_engine {

std::string ProgressTracker::next_action(WorkflowState state,
                                            const TaskPlan& plan) {
  std::ostringstream os;
  os << "[" << workflow_state_name(state) << "] ";
  switch (state) {
    case WorkflowState::Draft:
      os << "Awaiting user request.";
      break;
    case WorkflowState::Planning:
      os << "Plan coordinator is generating draft plan.";
      break;
    case WorkflowState::AwaitingClarification:
      os << "Awaiting user clarification (missing info: "
         << plan.missing_info.size() << ").";
      break;
    case WorkflowState::AwaitingApproval:
      os << "Awaiting user approval of plan v" << plan.version << ".";
      break;
    case WorkflowState::Executing: {
      std::unordered_set<TaskId> passed;
      for (const auto& t : plan.tasks) {
        if (t.status == TaskStatus::Passed) passed.insert(t.id);
      }
      std::string next_task;
      for (const auto& t : plan.tasks) {
        if (t.status == TaskStatus::Pending || t.status == TaskStatus::Ready) {
          bool ready = true;
          for (const auto& d : t.dependencies) {
            if (!passed.count(d)) { ready = false; break; }
          }
          if (ready) { next_task = t.id; break; }
        }
      }
      if (next_task.empty()) {
        os << "No eligible task; workflow may be blocked.";
      } else {
        os << "Next task: `" << next_task << "`.";
      }
      break;
    }
    case WorkflowState::Verifying:
      os << "Verifying last task's acceptance criteria.";
      break;
    case WorkflowState::Recovering:
      os << "Recovery manager is diagnosing the last failure.";
      break;
    case WorkflowState::Blocked:
      os << "Workflow blocked; review failed tasks and revise plan.";
      break;
    case WorkflowState::Paused:
      os << "Workflow paused; resume to continue.";
      break;
    case WorkflowState::Completed:
      os << "Workflow complete.";
      break;
    case WorkflowState::Cancelled:
      os << "Workflow cancelled.";
      break;
    case WorkflowState::Failed:
      os << "Workflow failed; see events for diagnosis.";
      break;
  }
  return os.str();
}

bool ProgressTracker::is_complete(const TaskPlan& plan) {
  if (plan.tasks.empty()) return false;
  // Spec §3: "A workflow containing blocked or failed required tasks must
  // not be reported as successfully completed." Spec §3: "Require all
  // mandatory tasks and acceptance criteria to pass verification before
  // declaring the overall goal complete."
  for (const auto& t : plan.tasks) {
    if (t.status != TaskStatus::Passed) return false;
    // Also check that every required acceptance criterion is Passed.
    for (const auto& a : t.acceptance_criteria) {
      if (a.required && a.status != CriterionStatus::Passed) return false;
    }
  }
  return true;
}

bool ProgressTracker::is_blocked(const TaskPlan& plan) {
  for (const auto& t : plan.tasks) {
    if (t.status == TaskStatus::Blocked) return true;
  }
  return false;
}

bool ProgressTracker::is_failed(const TaskPlan& plan) {
  for (const auto& t : plan.tasks) {
    if (t.status == TaskStatus::Failed) return true;
  }
  return false;
}

bool ProgressTracker::is_cancelled(const TaskPlan& plan) {
  for (const auto& t : plan.tasks) {
    if (t.status == TaskStatus::Cancelled) return true;
  }
  return false;
}

}  // namespace agent_engine
