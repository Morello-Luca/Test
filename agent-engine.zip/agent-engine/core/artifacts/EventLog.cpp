// EventLog.cpp

#include "EventLog.h"

#include <chrono>
#include <ctime>
#include <sstream>

namespace agent_engine {

namespace {

std::string iso_now() {
  using std::chrono::system_clock;
  auto now = system_clock::now();
  std::time_t t = system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&t, &tm);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
  return std::string(buf);
}

}  // namespace

EventLog::EventLog() = default;

void EventLog::append(WorkflowEvent ev) {
  std::vector<Subscriber> subs;
  {
    std::lock_guard<std::mutex> lk(mtx_);
    if (ev.timestamp_iso.empty()) ev.timestamp_iso = iso_now();
    events_.push_back(ev);
    subs.reserve(subscribers_.size());
    for (auto& [id, cb] : subscribers_) subs.push_back(cb);
  }
  // Subscribers notified outside the lock to avoid re-entrant deadlock.
  for (auto& cb : subs) cb(ev);
}

void EventLog::log(WorkflowEventKind kind,
                    std::string state,
                    std::string message,
                    std::map<std::string, std::string> details) {
  WorkflowEvent ev;
  ev.kind = kind;
  ev.workflow_state = std::move(state);
  ev.message = std::move(message);
  ev.details = std::move(details);
  append(std::move(ev));
}

std::vector<WorkflowEvent> EventLog::snapshot() const {
  std::lock_guard<std::mutex> lk(mtx_);
  return events_;
}

int EventLog::subscribe(Subscriber cb) {
  std::lock_guard<std::mutex> lk(mtx_);
  int id = ++next_sub_id_;
  subscribers_.emplace_back(id, std::move(cb));
  return id;
}

void EventLog::unsubscribe(int sub_id) {
  std::lock_guard<std::mutex> lk(mtx_);
  for (auto it = subscribers_.begin(); it != subscribers_.end(); ++it) {
    if (it->first == sub_id) {
      subscribers_.erase(it);
      return;
    }
  }
}

void EventLog::clear() {
  std::lock_guard<std::mutex> lk(mtx_);
  events_.clear();
}

}  // namespace agent_engine
