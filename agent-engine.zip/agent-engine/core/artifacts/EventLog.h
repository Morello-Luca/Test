// EventLog.h
//
// Authoritative structured log of workflow events. Spec §9: "These documents
// are views of the structured state, not the only source of truth."

#ifndef AGENT_ENGINE_CORE_ARTIFACTS_EVENT_LOG_H
#define AGENT_ENGINE_CORE_ARTIFACTS_EVENT_LOG_H

#include "core/models/ToolExecutionTypes.h"

#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace agent_engine {

/// Thread-safe append-only event log. All workflow components append events;
/// the Markdown renderer reads from this to produce progress.md.
class EventLog {
 public:
  EventLog();

  // Append an event; timestamp and current state filled in by log.
  void append(WorkflowEvent ev);

  // Convenience: build event from kind+message+details with auto timestamp.
  void log(WorkflowEventKind kind,
           std::string state,
           std::string message,
           std::map<std::string, std::string> details = {});

  // Read-only snapshot of all events.
  std::vector<WorkflowEvent> snapshot() const;

  // Subscribe to events; returns subscription id (use unsubscribe to remove).
  // The callback is invoked synchronously on append(); avoid re-entrancy.
  using Subscriber = std::function<void(const WorkflowEvent&)>;
  int subscribe(Subscriber cb);
  void unsubscribe(int sub_id);

  void clear();

 private:
  mutable std::mutex mtx_;
  std::vector<WorkflowEvent> events_;
  int next_sub_id_ = 0;
  std::vector<std::pair<int, Subscriber>> subscribers_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_ARTIFACTS_EVENT_LOG_H
