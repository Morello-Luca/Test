// MarkdownRenderer.h
//
// Spec §9: render three markdown views of structured state:
//   - task_plan.md
//   - findings.md
//   - progress.md
// These are VIEWS; the structured state is the source of truth.

#ifndef AGENT_ENGINE_CORE_ARTIFACTS_MARKDOWN_RENDERER_H
#define AGENT_ENGINE_CORE_ARTIFACTS_MARKDOWN_RENDERER_H

#include "core/models/DomainModels.h"
#include "core/artifacts/EventLog.h"

#include <string>

namespace agent_engine {

class MarkdownRenderer {
 public:
  explicit MarkdownRenderer(const EventLog& log) : log_(log) {}

  /// task_plan.md: goal, plan version, milestones, task ids, deps, acceptance
  /// criteria, task statuses, next eligible action.
  std::string render_task_plan(const TaskPlan& p) const;

  /// findings.md: discoveries, assumptions, context, decisions, constraints,
  /// info discovered during execution.
  std::string render_findings(const TaskPlan& p) const;

  /// progress.md: completed work, tool outcomes, verification results,
  /// errors, recovery attempts, blockers, next action.
  std::string render_progress(const TaskPlan& p,
                                const std::string& next_action) const;

 private:
  const EventLog& log_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_ARTIFACTS_MARKDOWN_RENDERER_H
