// MarkdownRenderer.cpp

#include "MarkdownRenderer.h"

#include <sstream>
#include <unordered_set>

namespace agent_engine {

namespace {

std::string status_brief(TaskStatus s) {
  switch (s) {
    case TaskStatus::Pending:               return " ";
    case TaskStatus::Ready:                  return "R";
    case TaskStatus::InProgress:             return "*";
    case TaskStatus::AwaitingVerification:   return "?";
    case TaskStatus::Passed:                 return "x";
    case TaskStatus::Failed:                 return "!";
    case TaskStatus::Blocked:                return "B";
    case TaskStatus::Skipped:                return "-";
    case TaskStatus::Cancelled:              return "C";
  }
  return "?";
}

}  // namespace

std::string MarkdownRenderer::render_task_plan(const TaskPlan& p) const {
  std::ostringstream os;
  os << "# Task Plan\n\n";
  os << "- Plan id: `" << p.plan_id << "`\n";
  os << "- Version: " << p.version
     << (p.approved ? " (approved)" : " (draft)") << "\n";
  os << "- Request id: `" << p.request_id << "`\n";
  os << "- Created: " << p.created_at_iso << "\n";
  os << "- Updated: " << p.updated_at_iso << "\n\n";

  os << "## Overall goal\n\n" << p.overall_goal << "\n\n";

  os << "## Milestones\n\n";
  if (p.milestones.empty()) os << "_(none)_\n";
  for (const auto& m : p.milestones) os << "1. " << m << "\n";
  os << "\n";

  os << "## Tasks\n\n";
  os << "| ID | Title | Status | Deps | Acceptance |\n";
  os << "|----|-------|--------|------|------------|\n";
  for (const auto& t : p.tasks) {
    std::string deps;
    for (size_t i = 0; i < t.dependencies.size(); ++i) {
      if (i) deps += ",";
      deps += t.dependencies[i];
    }
    if (deps.empty()) deps = "-";
    std::string ac = std::to_string(t.acceptance_criteria.size()) +
                     " criteria";
    os << "| `" << t.id << "` | " << t.title
       << " [" << status_brief(t.status) << "]"
       << " | " << task_status_name(t.status) << " | " << deps << " | "
       << ac << " |\n";
  }
  os << "\n";

  os << "## Acceptance criteria\n\n";
  os << "_Checkbox legend: `[ ]` defined · `[.]` pending · `[x]` passed · "
     << "`[!]` failed · `[B]` blocked · `[-]` skipped. Required flag "
     << "shown as `R`/`O`._\n\n";
  for (const auto& t : p.tasks) {
    if (t.acceptance_criteria.empty()) continue;
    os << "### " << t.id << " — " << t.title
       << " [" << status_brief(t.status) << "]\n";
    for (const auto& a : t.acceptance_criteria) {
      os << "- [" << criterion_status_mark(a.status) << "] "
         << "(" << (a.required ? "R" : "O") << ") `"
         << a.id << "` " << a.description
         << " _" << criterion_status_name(a.status) << "_\n";
    }
    os << "\n";
  }

  os << "## Risks & assumptions\n\n";
  if (p.risks.empty() && p.assumptions.empty() && p.missing_info.empty()) {
    os << "_(none)_\n";
  }
  if (!p.risks.empty()) {
    os << "### Risks\n";
    for (const auto& r : p.risks) os << "- " << r << "\n";
  }
  if (!p.assumptions.empty()) {
    os << "### Assumptions\n";
    for (const auto& a : p.assumptions) os << "- " << a << "\n";
  }
  if (!p.missing_info.empty()) {
    os << "### Missing info\n";
    for (const auto& m : p.missing_info) os << "- " << m << "\n";
  }
  os << "\n";

  // Identify next eligible action: first task in Pending/Ready state with
  // all deps satisfied.
  os << "## Next eligible action\n\n";
  std::string next_task;
  std::unordered_set<TaskId> passed;
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Passed) passed.insert(t.id);
  }
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Pending || t.status == TaskStatus::Ready) {
      bool ready = true;
      for (const auto& d : t.dependencies) {
        if (!passed.count(d)) { ready = false; break; }
      }
      if (ready) { next_task = t.id; break; }
    }
  }
  if (next_task.empty()) {
    os << "_No eligible task; plan appears complete or fully blocked._\n";
  } else {
    os << "Next task: `" << next_task << "`\n";
  }
  return os.str();
}

std::string MarkdownRenderer::render_findings(const TaskPlan& p) const {
  std::ostringstream os;
  os << "# Findings\n\n";
  os << "Discoveries, assumptions, context, decisions, and constraints "
     << "observed during planning and execution.\n\n";

  if (!p.missing_info.empty()) {
    os << "## Missing information\n\n";
    for (const auto& m : p.missing_info) os << "- " << m << "\n";
    os << "\n";
  }
  if (!p.assumptions.empty()) {
    os << "## Assumptions\n\n";
    for (const auto& a : p.assumptions) os << "- " << a << "\n";
    os << "\n";
  }
  if (!p.risks.empty()) {
    os << "## Risks\n\n";
    for (const auto& r : p.risks) os << "- " << r << "\n";
    os << "\n";
  }
  if (!p.findings.empty()) {
    os << "## Discovered during execution\n\n";
    for (const auto& f : p.findings) os << "- " << f << "\n";
    os << "\n";
  }
  if (p.findings.empty() && p.assumptions.empty() && p.risks.empty() &&
      p.missing_info.empty()) {
    os << "_No findings recorded yet._\n";
  }
  return os.str();
}

std::string MarkdownRenderer::render_progress(const TaskPlan& p,
                                                const std::string& next_action)
    const {
  std::ostringstream os;
  os << "# Progress\n\n";
  os << "Plan v" << p.version << " (" << (p.approved ? "approved" : "draft")
     << ")\n\n";

  os << "## Task status\n\n";
  os << "| ID | Title | Status | Attempts (initial+retries/max) | Calls | Prior failure |\n";
  os << "|----|-------|--------|-------------------------------|-------|---------------|\n";
  for (const auto& t : p.tasks) {
    os << "| `" << t.id << "` | " << t.title << " | "
       << task_status_name(t.status) << " | "
       << t.attempts << " (" << t.retries_used() << "+" << (t.attempts > 0 ? 1 : 0)
       << "/" << t.max_retries << ") | "
       << t.executed_calls.size() << " | "
       << (t.prior_failure_reason.empty() ? "-" : t.prior_failure_reason)
       << " |\n";
  }
  os << "\n";

  os << "## Tool outcomes\n\n";
  bool any = false;
  for (const auto& t : p.tasks) {
    for (const auto& c : t.executed_calls) {
      any = true;
      os << "- `" << c.tool_call_id << "` `" << c.tool_name << "` on `"
         << t.id << "` — "
         << (c.ok ? "ok" : "FAILED");
      if (!c.error.empty()) os << " (" << c.error << ")";
      os << "\n";
    }
  }
  if (!any) os << "_No tool calls recorded yet._\n";
  os << "\n";

  os << "## Events (last 25)\n\n";
  auto events = log_.snapshot();
  size_t start = events.size() > 25 ? events.size() - 25 : 0;
  for (size_t i = start; i < events.size(); ++i) {
    os << "- " << events[i].timestamp_iso << " ["
       << workflow_event_kind_name(events[i].kind) << "] "
       << events[i].message << "\n";
  }
  os << "\n";

  os << "## Blockers\n\n";
  bool blocked = false;
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Blocked) {
      blocked = true;
      os << "- Task `" << t.id << "` is blocked.\n";
    }
  }
  if (!blocked) os << "_No blockers._\n";
  os << "\n";

  os << "## Next action\n\n";
  os << (next_action.empty() ? "_None scheduled._" : next_action) << "\n";
  return os.str();
}

}  // namespace agent_engine
