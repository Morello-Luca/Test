// WorkflowController.h
//
// Spec §8: "Centralize valid state transitions in the workflow controller.
// Do not let arbitrary components change workflow state without validation."
//
// WorkflowController owns the current WorkflowState + is the single choke
// point for transitions. AgentEngine delegates all state changes here.

#ifndef AGENT_ENGINE_CORE_WORKFLOW_CONTROLLER_H
#define AGENT_ENGINE_CORE_WORKFLOW_CONTROLLER_H

#include "core/WorkflowState.h"
#include "core/artifacts/EventLog.h"

#include <string>

namespace agent_engine {

class WorkflowController {
 public:
  WorkflowController(EventLog& log);

  WorkflowState state() const { return state_; }

  /// Attempt a transition. Returns true if the transition was valid and
  /// applied. Returns false and logs an error otherwise. Spec §8: only
  /// valid transitions are accepted.
  bool transition_to(WorkflowState next, const std::string& reason = "");

  /// Returns true if `state_` is terminal.
  bool is_terminal() const;

 private:
  EventLog& log_;
  WorkflowState state_ = WorkflowState::Draft;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_WORKFLOW_CONTROLLER_H
