// ToolDispatcher.cpp

#include "ToolDispatcher.h"

namespace agent_engine {

ToolResult ToolDispatcher::dispatch(PlanTask& task, const ToolCall& call) {
  log_.log(WorkflowEventKind::ToolDispatched, "Executing",
           "dispatch " + call.tool_name,
           {{"task_id", call.task_id}, {"origin", call.origin}});

  ToolResult r;
  r.invocation_id = call.id;
  r.tool_name = call.tool_name;

  ITool* tool = registry_.get(call.tool_name);
  if (!tool) {
    r.ok = false;
    r.error = "unauthorized tool: " + call.tool_name;
    PlanTask::ExecutedCall ec;
    ec.tool_call_id = call.id;
    ec.tool_name = call.tool_name;
    ec.arguments_json = call.arguments_json;
    ec.ok = false;
    ec.error = r.error;
    task.executed_calls.push_back(std::move(ec));
    log_.log(WorkflowEventKind::ToolResultObtained, "Executing",
             "unauthorized tool rejected: " + call.tool_name,
             {{"invocation_id", call.id}});
    return r;
  }

  if (auto err = tool->validate_arguments(call.arguments_json); !err.empty()) {
    r.ok = false;
    r.error = "invalid args: " + err;
    PlanTask::ExecutedCall ec;
    ec.tool_call_id = call.id;
    ec.tool_name = call.tool_name;
    ec.arguments_json = call.arguments_json;
    ec.ok = false;
    ec.error = r.error;
    task.executed_calls.push_back(std::move(ec));
    log_.log(WorkflowEventKind::ToolResultObtained, "Executing",
             "invalid args for " + call.tool_name,
             {{"invocation_id", call.id}});
    return r;
  }

  auto out = tool->execute(call);
  log_.log(WorkflowEventKind::ToolResultObtained, "Executing",
           call.tool_name + " " + (out.ok ? "ok" : "failed"),
           {{"invocation_id", call.id},
            {"ok", out.ok ? "true" : "false"},
            {"untrusted", out.untrusted_content_flagged ? "true" : "false"}});

  PlanTask::ExecutedCall ec;
  ec.tool_call_id = call.id;
  ec.tool_name = call.tool_name;
  ec.arguments_json = call.arguments_json;
  ec.result_json = out.output;
  ec.ok = out.ok;
  ec.error = out.error;
  task.executed_calls.push_back(std::move(ec));

  return out;
}

std::vector<ToolResult> ToolDispatcher::dispatch_batch(
    PlanTask& task, const std::vector<ToolCall>& calls) {
  std::vector<ToolResult> out;
  out.reserve(calls.size());
  for (const auto& c : calls) {
    out.push_back(dispatch(task, c));
  }
  return out;
}

bool ToolDispatcher::authorized(const std::string& tool_name) const {
  return registry_.get(tool_name) != nullptr;
}

}  // namespace agent_engine
