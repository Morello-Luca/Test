// RecoveryManager.cpp

#include "RecoveryManager.h"

#include <chrono>
#include <ctime>
#include <sstream>

namespace agent_engine {

namespace {

std::string iso_now() {
  using std::chrono::system_clock;
  auto now = system_clock::now();
  std::time_t t = system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&t, &tm);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
  return std::string(buf);
}

std::string summarize_verification(const VerificationResult& vr) {
  std::ostringstream os;
  if (vr.overall_passed) {
    os << "verification passed";
    return os.str();
  }
  if (!vr.missing_evidence.empty()) {
    os << "missing evidence (" << vr.missing_evidence.size()
       << " criteria)";
    return os.str();
  }
  if (!vr.failed_criteria.empty()) {
    os << "failed criteria (" << vr.failed_criteria.size() << ")";
    return os.str();
  }
  os << "verification did not pass";
  return os.str();
}

}  // namespace

RecoveryManager::RecoveryManager(EventLog& log, const ResultVerifier& verifier)
    : log_(log), verifier_(verifier) {}

RecoveryDecision RecoveryManager::diagnose(
    const TaskPlan& /*plan*/,
    const PlanTask& task,
    const VerificationResult& verification) {
  RecoveryDecision d;
  d.cause = verification.cause.empty()
                ? summarize_verification(verification)
                : verification.cause;

  // Spec §4: clarify retry accounting. `attempts` counts total execution
  // attempts (initial + retries). `max_retries` counts retries AFTER the
  // initial attempt. `can_retry()` returns true while retries_used() <
  // max_retries. Spec §2: "Avoid repeating an identical failing action
  // indefinitely."
  if (!verification.missing_evidence.empty()) {
    if (task.can_retry()) {
      d.action = RecoveryAction::RetryTask;
      d.reason = "missing evidence; retry "
                 "(attempt " + std::to_string(task.attempts) +
                 " done, " + std::to_string(task.retries_remaining()) +
                 " retries remaining of max " +
                 std::to_string(task.max_retries) + ")";
      log_.log(WorkflowEventKind::RecoveryStarted, "Recovering",
               task.id + ": retry on missing evidence",
               {{"attempts", std::to_string(task.attempts)},
                {"retries_used", std::to_string(task.retries_used())},
                {"retries_remaining",
                 std::to_string(task.retries_remaining())},
                {"max_retries", std::to_string(task.max_retries)}});
      return d;
    }
    // Out of retries: block the task so the workflow cannot complete
    // (spec §3: a blocked task prevents successful workflow completion).
    d.action = RecoveryAction::BlockTask;
    d.reason = "missing evidence and retries exhausted ("
               + std::to_string(task.retries_used()) + "/"
               + std::to_string(task.max_retries) + ")";
    log_.log(WorkflowEventKind::RecoveryFinished, "Recovering",
             task.id + ": blocked (retries exhausted)",
             {{"attempts", std::to_string(task.attempts)}});
    return d;
  }

  if (!verification.failed_criteria.empty()) {
    if (task.can_retry()) {
      d.action = RecoveryAction::RetryTask;
      d.reason = "verification failed; retry "
                 "(" + std::to_string(task.retries_used()) + "/"
                 + std::to_string(task.max_retries) + " retries used)";
      log_.log(WorkflowEventKind::RecoveryStarted, "Recovering",
               task.id + ": retry on failed criteria",
               {{"retries_remaining",
                 std::to_string(task.retries_remaining())}});
      return d;
    }
    // Out of retries on a hard failure. Material change required to
    // recover; bounce back to AwaitingApproval per spec §4.3 and §7.
    d.action = RecoveryAction::RevisePlan;
    d.reason = "verification failed repeatedly; plan revision required "
               "(retries exhausted: " +
               std::to_string(task.retries_used()) + "/" +
               std::to_string(task.max_retries) + ")";
    log_.log(WorkflowEventKind::RecoveryFinished, "Recovering",
             task.id + ": escalate to plan revision");
    return d;
  }

  // Verification passed: no recovery needed.
  d.action = RecoveryAction::SkipTask;
  d.reason = "verification passed; nothing to recover";
  return d;
}

void RecoveryManager::apply(TaskPlan& plan, const PlanTask& task,
                              const RecoveryDecision& decision) {
  PlanTask* t = plan.find_task(task.id);
  if (!t) return;
  switch (decision.action) {
    case RecoveryAction::RetryTask:
      t->status = TaskStatus::Pending;
      t->has_unverified_claim = false;
      // Spec §2: "Feed the failure context into the next permitted
      // recovery attempt." Preserve the failure reason so the AgentLoop
      // can include it in the next inference's context.
      t->prior_failure_reason = decision.reason +
          " | cause: " + decision.cause;
      // Don't reset executed_calls — they're useful context for the
      // next attempt. Recovery should preserve useful context (spec §7).
      log_.log(WorkflowEventKind::RecoveryFinished, "Recovering",
               t->id + ": retry scheduled (prior_failure_reason set)",
               {{"reason", decision.reason}});
      break;
    case RecoveryAction::BlockTask:
      t->status = TaskStatus::Blocked;
      t->prior_failure_reason = decision.reason + " | cause: " + decision.cause;
      log_.log(WorkflowEventKind::TaskBlocked, "Recovering",
               t->id + " blocked: " + decision.reason,
               {{"cause", decision.cause}});
      break;
    case RecoveryAction::FailTask:
      t->status = TaskStatus::Failed;
      t->prior_failure_reason = decision.reason + " | cause: " + decision.cause;
      log_.log(WorkflowEventKind::TaskFailed, "Recovering",
               t->id + " failed: " + decision.reason,
               {{"cause", decision.cause}});
      break;
    case RecoveryAction::FailWorkflow:
      t->status = TaskStatus::Failed;
      t->prior_failure_reason = decision.reason + " | cause: " + decision.cause;
      log_.log(WorkflowEventKind::WorkflowFailed, "Recovering",
               "workflow failed: " + decision.reason,
               {{"cause", decision.cause}});
      break;
    case RecoveryAction::RevisePlan:
      // Spec §4.3 / §7: bump version + mark plan not approved so
      // WorkflowController can bounce back to AwaitingApproval. Recovery
      // deliberately invalidates approval so the user must re-approve.
      plan.version += 1;
      plan.updated_at_iso = iso_now();
      plan.approved = false;
      t->status = TaskStatus::Blocked;  // until re-approved
      t->prior_failure_reason = decision.reason + " | cause: " + decision.cause;
      log_.log(WorkflowEventKind::PlanRevised, "Recovering",
               "plan revised to v" + std::to_string(plan.version) +
               " (recovery-driven, approval invalidated): " +
               decision.reason,
               {{"cause", decision.cause}});
      break;
    case RecoveryAction::SkipTask:
      // No-op.
      log_.log(WorkflowEventKind::RecoveryFinished, "Recovering",
               t->id + ": no recovery needed");
      break;
  }
}

}  // namespace agent_engine
