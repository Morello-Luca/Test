// TaskScheduler.h
//
// Spec §5: "Select the next eligible task." Tasks are eligible when their
// dependencies have all passed and their status is Pending or Ready.

#ifndef AGENT_ENGINE_CORE_EXECUTION_TASK_SCHEDULER_H
#define AGENT_ENGINE_CORE_EXECUTION_TASK_SCHEDULER_H

#include "core/models/DomainModels.h"

#include <optional>
#include <string>
#include <vector>

namespace agent_engine {

class TaskScheduler {
 public:
  /// Returns the next eligible task, or empty optional if none.
  /// Order: respect dependency graph; among ready tasks, return the first
  /// in declaration order (priority order — ChangePriority edits reorder).
  std::optional<PlanTask> next_eligible(const TaskPlan& p) const;

  /// Mark a task as Ready (deps satisfied) and return a list of IDs that
  /// became newly ready as a result of `just_passed_id` completing.
  std::vector<TaskId> propagate_status(const TaskPlan& p,
                                        const TaskId& just_passed_id) const;

  /// True if every task is in a terminal state (Passed / Failed /
  /// Skipped / Cancelled). Used by the loop to know when to stop.
  bool all_terminal(const TaskPlan& p) const;

  /// True if any task is Blocked.
  bool has_blocked(const TaskPlan& p) const;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_EXECUTION_TASK_SCHEDULER_H
