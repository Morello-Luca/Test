// AgentLoop.cpp

#include "AgentLoop.h"

#include <chrono>
#include <ctime>
#include <sstream>
#include <unordered_set>

namespace agent_engine {

namespace {

std::string iso_now() {
  using std::chrono::system_clock;
  auto now = system_clock::now();
  std::time_t t = system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&t, &tm);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
  return std::string(buf);
}

std::string fresh_call_id() {
  static int counter = 0;
  std::ostringstream os;
  os << "call_" << (++counter) << "_" << iso_now();
  return os.str();
}

}  // namespace

AgentLoop::AgentLoop(IModelAdapter& adapter,
                     ToolRegistry& registry,
                     ToolDispatcher& dispatcher,
                     TaskScheduler& scheduler,
                     EventLog& log,
                     AgentLoopLimits limits)
    : adapter_(adapter),
      registry_(registry),
      dispatcher_(dispatcher),
      scheduler_(scheduler),
      log_(log),
      limits_(limits) {}

std::vector<AdapterMessage> AgentLoop::build_context(const TaskPlan& plan,
                                                        const PlanTask& task)
    const {
  std::vector<AdapterMessage> msgs;
  AdapterMessage system;
  system.role = "system";
  system.content =
      "You are an agent executing a structured workflow. You may call tools. "
      "When the task is done, respond with finish_reason=stop and an "
      "assertion of success. Independent verification will follow. "
      "STOPPING WITHOUT HAVING MADE A TOOL CALL IS NOT ACCEPTABLE: a "
      "model's assertion of success is not proof that work occurred. "
      "If you cannot complete the task, request clarification or "
      "explicitly report that you cannot proceed.";
  msgs.push_back(system);

  AdapterMessage user;
  user.role = "user";
  std::ostringstream os;
  os << "Plan goal: " << plan.overall_goal << "\n"
     << "Current task: " << task.title << "\n"
     << "Description: " << task.description << "\n"
     << "Dependencies satisfied: yes\n"
     << "Attempt " << task.attempts << " of " << (task.max_retries + 1)
     << " (initial + " << task.max_retries << " retries).\n";
  user.content = os.str();
  msgs.push_back(user);

  // Spec §2: "Feed the failure context into the next permitted recovery
  // attempt. Avoid repeating an identical inference without new information
  // or a changed recovery strategy."
  if (!task.prior_failure_reason.empty()) {
    AdapterMessage guidance;
    guidance.role = "system";
    guidance.content =
        "Your previous attempt at this task FAILED verification. Reason: "
        + task.prior_failure_reason + ". You MUST take a different action "
        "this time: either (a) make a tool call that produces evidence "
        "the verifier can check, (b) request clarification if information "
        "is missing, or (c) explicitly state in your response that you "
        "cannot proceed. DO NOT simply respond with finish_reason=stop and "
        "an assertion of success; the verifier will reject that again and "
        "the task will eventually be blocked.";
    msgs.push_back(std::move(guidance));
  }
  return msgs;
}

LoopOutcome AgentLoop::run_task(TaskPlan& plan, const TaskId& task_id) {
  PlanTask* task = plan.find_task(task_id);
  if (!task) return LoopOutcome::TaskFailed;

  // Spec §5: select next eligible task; ensure deps satisfied.
  std::unordered_set<TaskId> passed;
  for (const auto& t : plan.tasks) {
    if (t.status == TaskStatus::Passed) passed.insert(t.id);
  }
  for (const auto& dep : task->dependencies) {
    if (!passed.count(dep)) {
      log_.log(WorkflowEventKind::TaskBlocked, "Executing",
               task_id + " blocked: missing dep " + dep);
      task->status = TaskStatus::Blocked;
      return LoopOutcome::TaskBlocked;
    }
  }

  task->status = TaskStatus::InProgress;
  task->attempts += 1;
  // Spec §4: clear prior_failure_reason at the START of a new attempt so
  // the loop can detect if the model gives an identical unproductive stop
  // response this turn (vs. legitimately inheriting context from earlier
  // recovery).
  std::string inherited_failure = task->prior_failure_reason;
  task->prior_failure_reason.clear();

  log_.log(WorkflowEventKind::TaskSelected, "Executing",
           "selected " + task_id,
           {{"attempt", std::to_string(task->attempts)},
            {"retries_used", std::to_string(task->retries_used())},
            {"max_retries", std::to_string(task->max_retries)},
            {"inherited_failure", inherited_failure.empty() ? "no" : "yes"}});
  if (on_select_) on_select_(task_id);

  std::string tools_json = registry_.describe_all_as_json();
  int calls_this_task = 0;

  // Spec §2: "Avoid repeating an identical inference without new
  // information or a changed recovery strategy." Track the last stop
  // response we got so we can detect identical repeats.
  std::string last_stop_content;

  for (int iter = 0; iter < limits_.max_iterations; ++iter) {
    if (++total_iterations_ > limits_.max_iterations) {
      log_.log(WorkflowEventKind::IterationLimitReached, "Executing",
               "iteration limit reached on " + task_id);
      return LoopOutcome::IterationLimitReached;
    }
    auto ctx = build_context(plan, *task);
    // Attach prior tool results so the model can see them.
    for (const auto& ec : task->executed_calls) {
      AdapterMessage m;
      m.role = "tool";
      std::ostringstream os;
      os << "call_id=" << ec.tool_call_id << " tool=" << ec.tool_name
         << " ok=" << (ec.ok ? "true" : "false") << "\n"
         << (ec.ok ? ec.result_json : ec.error);
      m.content = os.str();
      ctx.push_back(std::move(m));
    }

    log_.log(WorkflowEventKind::ModelInferenceStarted, "Executing",
             "infer " + task_id);
    auto response = adapter_.infer(ctx, tools_json);
    log_.log(WorkflowEventKind::ModelInferenceFinished, "Executing",
             "infer done: " + response.finish_reason);

    // Spec §7: distinguish model-asserted success from verified success.
    // Spec §2: "A model's final response must not be treated as proof
    // that implementation work occurred."
    if (response.finish_reason == "stop") {
      // Spec §2: detect unproductive stops. If the model stops without
      // making any tool calls AND it already stopped identically on a
      // prior iteration of this task, refuse to mark AwaitingVerification
      // and force the loop into recovery with an explicit failure reason.
      bool had_tool_calls = !response.tool_calls.empty();
      if (!had_tool_calls && response.content == last_stop_content &&
          !inherited_failure.empty()) {
        // Identical unproductive stop after explicit guidance. Force
        // failure with a clear explanation rather than rubber-stamping.
        task->has_unverified_claim = true;
        task->status = TaskStatus::AwaitingVerification;
        task->prior_failure_reason =
            "model returned an identical stop response ('"
            + response.content +
            "') without making any tool calls, despite explicit guidance "
            "to produce evidence or request clarification";
        log_.log(WorkflowEventKind::Note, "Executing",
                 task_id + ": identical unproductive stop detected");
        return LoopOutcome::TaskAwaitingVerification;
      }
      last_stop_content = response.content;
      task->has_unverified_claim = true;
      task->status = TaskStatus::AwaitingVerification;
      return LoopOutcome::TaskAwaitingVerification;
    }
    if (response.finish_reason == "error" ||
        response.tool_calls.empty()) {
      // No further action; loop again next iteration unless attempts
      // exhausted. The RecoveryManager handles bounded retries.
      if (!task->can_retry()) {
        task->status = TaskStatus::Failed;
        task->prior_failure_reason =
            "model returned error/empty response and retries are exhausted";
        return LoopOutcome::TaskFailed;
      }
      task->attempts += 1;
      continue;
    }

    // Dispatch any tool calls.
    for (const auto& tc : response.tool_calls) {
      if (calls_this_task++ >= limits_.max_tool_calls_per_task) {
        log_.log(WorkflowEventKind::ToolDispatched, "Executing",
                 "per-task tool call limit reached");
        return LoopOutcome::ToolCallLimitReached;
      }
      if (++total_tool_calls_ > limits_.max_total_tool_calls) {
        return LoopOutcome::ToolCallLimitReached;
      }
      ToolCall call;
      call.id = fresh_call_id();
      call.task_id = task_id;
      call.tool_name = tc.name;
      call.arguments_json = tc.arguments_json;
      call.origin = "model";

      ITool* tool = registry_.get(call.tool_name);
      if (interceptor_ && !interceptor_(call, tool)) {
        ToolResult r;
        r.invocation_id = call.id;
        r.tool_name = call.tool_name;
        r.ok = false;
        r.error = "interceptor denied call";
        PlanTask::ExecutedCall ec;
        ec.tool_call_id = call.id;
        ec.tool_name = call.tool_name;
        ec.arguments_json = call.arguments_json;
        ec.ok = false;
        ec.error = r.error;
        task->executed_calls.push_back(std::move(ec));
        log_.log(WorkflowEventKind::ToolResultObtained, "Executing",
                 "denied: " + call.tool_name);
        continue;
      }
      dispatcher_.dispatch(*task, call);
    }
  }

  // Iteration limit reached without completion.
  log_.log(WorkflowEventKind::IterationLimitReached, "Executing",
           "iteration limit on " + task_id);
  return LoopOutcome::IterationLimitReached;
}

}  // namespace agent_engine
