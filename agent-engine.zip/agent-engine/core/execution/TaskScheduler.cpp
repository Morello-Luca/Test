// TaskScheduler.cpp

#include "TaskScheduler.h"

#include <unordered_set>

namespace agent_engine {

namespace {

bool deps_satisfied(const PlanTask& t,
                     const std::unordered_set<TaskId>& passed) {
  for (const auto& d : t.dependencies) {
    if (!passed.count(d)) return false;
  }
  return true;
}

bool is_terminal(TaskStatus s) {
  return s == TaskStatus::Passed || s == TaskStatus::Failed ||
         s == TaskStatus::Skipped || s == TaskStatus::Cancelled;
}

}  // namespace

std::optional<PlanTask> TaskScheduler::next_eligible(const TaskPlan& p)
    const {
  std::unordered_set<TaskId> passed;
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Passed) passed.insert(t.id);
  }
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Pending || t.status == TaskStatus::Ready) {
      if (deps_satisfied(t, passed)) {
        return t;
      }
    }
  }
  return std::nullopt;
}

std::vector<TaskId> TaskScheduler::propagate_status(const TaskPlan& p,
                                                      const TaskId& just_passed_id)
    const {
  std::unordered_set<TaskId> passed;
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Passed) passed.insert(t.id);
  }
  // Ensure the just-passed one is included even if state not yet updated.
  passed.insert(just_passed_id);

  std::vector<TaskId> newly_ready;
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Pending && deps_satisfied(t, passed)) {
      newly_ready.push_back(t.id);
    }
  }
  return newly_ready;
}

bool TaskScheduler::all_terminal(const TaskPlan& p) const {
  for (const auto& t : p.tasks) {
    if (!is_terminal(t.status)) return false;
  }
  return true;
}

bool TaskScheduler::has_blocked(const TaskPlan& p) const {
  for (const auto& t : p.tasks) {
    if (t.status == TaskStatus::Blocked) return true;
  }
  return false;
}

}  // namespace agent_engine
