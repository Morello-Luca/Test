// AgentLoop.h
//
// Spec §5: iterative agent loop that selects the next task, builds the model
// context, requests inference, parses tool calls, dispatches authorized
// calls, collects results, and continues until completion, clarification,
// or final response. Bounded by iteration / tool-call / retry limits.
//
// Spec §7: distinguishes model-asserted success from independently verified
// success. The loop does NOT mark a task Passed just because the model said
// "done" — it marks AwaitingVerification and hands off to ResultVerifier.

#ifndef AGENT_ENGINE_CORE_EXECUTION_AGENT_LOOP_H
#define AGENT_ENGINE_CORE_EXECUTION_AGENT_LOOP_H

#include "core/models/DomainModels.h"
#include "core/tools/IModelAdapter.h"
#include "core/tools/ToolRegistry.h"
#include "TaskScheduler.h"
#include "ToolDispatcher.h"
#include "core/artifacts/EventLog.h"

#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace agent_engine {

struct AgentLoopLimits {
  int max_iterations = 20;
  int max_tool_calls_per_task = 10;
  int max_total_tool_calls = 50;
};

/// Outcome of one task run.
enum class LoopOutcome {
  TaskAwaitingVerification,   // model asserted success but not yet verified
  TaskFailed,                  // attempts exhausted
  TaskBlocked,                 // missing dependency / cannot proceed
  IterationLimitReached,
  ToolCallLimitReached,
  Cancelled,
  ClarificationNeeded,         // loop detected ambiguity mid-execution
};

class AgentLoop {
 public:
  using TaskSelectedCallback = std::function<void(const TaskId&)>;
  using ToolCallInterceptor =
      std::function<bool(const ToolCall&, const ITool*)>;

  AgentLoop(IModelAdapter& adapter,
            ToolRegistry& registry,
            ToolDispatcher& dispatcher,
            TaskScheduler& scheduler,
            EventLog& log,
            AgentLoopLimits limits = {});

  /// Run the agent loop on a single task. Mutates `plan` (updates task
  /// status, executed_calls, attempts). The loop leaves the task in
  /// AwaitingVerification if the model asserts success, Failed on retry
  /// exhaustion, or Blocked when dependencies cannot be satisfied.
  LoopOutcome run_task(TaskPlan& plan, const TaskId& task_id);

  void set_task_selected_cb(TaskSelectedCallback cb) { on_select_ = std::move(cb); }

  /// Optional interceptor: returns false to forbid a tool call before it
  /// reaches the dispatcher (e.g., for unauthorized shell access).
  void set_tool_interceptor(ToolCallInterceptor ci) {
    interceptor_ = std::move(ci);
  }

  int total_tool_calls() const { return total_tool_calls_; }
  int total_iterations() const { return total_iterations_; }

 private:
  IModelAdapter& adapter_;
  ToolRegistry& registry_;
  ToolDispatcher& dispatcher_;
  TaskScheduler& scheduler_;
  EventLog& log_;
  AgentLoopLimits limits_;
  TaskSelectedCallback on_select_;
  ToolCallInterceptor interceptor_;

  int total_tool_calls_ = 0;
  int total_iterations_ = 0;

  std::vector<AdapterMessage> build_context(const TaskPlan& plan,
                                              const PlanTask& task) const;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_EXECUTION_AGENT_LOOP_H
