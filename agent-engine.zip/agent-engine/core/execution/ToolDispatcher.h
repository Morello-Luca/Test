// ToolDispatcher.h
//
// Spec §5 / §6: dispatches authorized tool calls. Validates arguments via
// the ITool contract, enforces path / origin checks, attaches results to
// the originating PlanTask, and routes untrusted content flags back to the
// agent loop. Bounded by the workflow policy: unauthorized calls are
// rejected without execution.

#ifndef AGENT_ENGINE_CORE_EXECUTION_TOOL_DISPATCHER_H
#define AGENT_ENGINE_CORE_EXECUTION_TOOL_DISPATCHER_H

#include "core/models/DomainModels.h"
#include "core/models/ToolExecutionTypes.h"
#include "core/tools/ToolRegistry.h"
#include "core/artifacts/EventLog.h"

#include <string>
#include <vector>

namespace agent_engine {

class ToolDispatcher {
 public:
  ToolDispatcher(ToolRegistry& registry, EventLog& log)
      : registry_(registry), log_(log) {}

  /// Dispatch one tool call. Records the call + result on the originating
  /// PlanTask, logs WorkflowEventKind::ToolDispatched/ToolResultObtained,
  /// and returns the structured result. Unauthorized tools / invalid args
  /// produce a failed ToolResult without invoking the tool.
  ToolResult dispatch(PlanTask& task, const ToolCall& call);

  /// Dispatch a batch of calls, respecting per-call dependency order
  /// (calls within the batch execute sequentially — the framework does not
  /// promise parallelism). Spec §5: "Support multiple tool calls when
  /// appropriate, subject to dependency ordering and safety constraints."
  std::vector<ToolResult> dispatch_batch(
      PlanTask& task, const std::vector<ToolCall>& calls);

  /// Whether a tool name is registered (and therefore authorized).
  bool authorized(const std::string& tool_name) const;

 private:
  ToolRegistry& registry_;
  EventLog& log_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_EXECUTION_TOOL_DISPATCHER_H
