// ResultVerifier.h
//
// Spec §7 (verification): checks task-specific acceptance criteria using
// available evidence (tool outputs, executed calls, resulting state).
// Verification results indicate: Passed / Failed criteria, Missing
// evidence, Recommended next action.
//
// Distinct from Recovery: verifier only JUDGES; recovery ACTS.

#ifndef AGENT_ENGINE_CORE_EXECUTION_RESULT_VERIFIER_H
#define AGENT_ENGINE_CORE_EXECUTION_RESULT_VERIFIER_H

#include "core/models/DomainModels.h"
#include "core/artifacts/EventLog.h"

#include <string>
#include <vector>

namespace agent_engine {

struct VerificationResult {
  TaskId task_id;
  std::vector<std::string> passed_criteria;
  std::vector<std::string> failed_criteria;
  std::vector<std::string> missing_evidence;
  std::string recommended_action;  // "pass" | "retry" | "block" | "revise"
  std::string cause;                // human-readable reason for the result
  bool overall_passed = false;
};

/// Apply a verification result onto a PlanTask by setting each
/// acceptance criterion's status field. This is the ONLY place criteria
/// transition out of Defined. Spec §1: criteria must not be marked Passed
/// before verification. Declared in the header so AgentEngine can call it
/// after the verifier has run.
void apply_verification_to_task(PlanTask& task,
                                 const VerificationResult& vr);

class ResultVerifier {
 public:
  using VerifyFn = std::function<VerificationResult(
      const TaskPlan&, const PlanTask&)>;

  explicit ResultVerifier(EventLog& log);

  /// Default verifier: walks the task's acceptance_criteria and uses the
  /// task's executed_calls as evidence. Heuristic per criterion:
  ///   - If any executed call failed → fail that criterion (unless the
  ///     criterion description hints it's optional).
  ///   - If the task has a `has_unverified_claim` flag but zero executed
  ///     calls → mark all criteria as "missing evidence".
  ///   - Otherwise pass.
  /// Production code would inject a real VerifyFn.
  VerificationResult verify(const TaskPlan& plan, const PlanTask& task) const;

  void set_verify_fn(VerifyFn fn) { fn_ = std::move(fn); }

 private:
  EventLog& log_;
  VerifyFn fn_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_EXECUTION_RESULT_VERIFIER_H
