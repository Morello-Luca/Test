// ResultVerifier.cpp

#include "ResultVerifier.h"

#include <algorithm>
#include <sstream>

namespace agent_engine {

ResultVerifier::ResultVerifier(EventLog& log) : log_(log) {}

VerificationResult ResultVerifier::verify(const TaskPlan& /*plan*/,
                                            const PlanTask& task) const {
  if (fn_) return fn_(/*plan=*/{}, task);  // overridden path
  VerificationResult r;
  r.task_id = task.id;
  log_.log(WorkflowEventKind::VerificationStarted, "Verifying",
           "verifying " + task.id,
           {{"criteria", std::to_string(task.acceptance_criteria.size())},
            {"attempts", std::to_string(task.attempts)},
            {"max_retries", std::to_string(task.max_retries)}});

  // Spec §1: criteria must NOT be marked Passed before verification. We
  // take a const ref so we can't accidentally mutate `task`; instead we
  // build the verification result and let the caller apply it.
  bool any_failed_call = false;
  for (const auto& ec : task.executed_calls) {
    if (!ec.ok) any_failed_call = true;
  }

  // Spec §7: distinguish model-asserted success from verified success.
  // A model stopping without tool calls is an unverified claim that
  // has produced zero evidence; the verifier must fail the task rather
  // than rubber-stamp it.
  if (task.has_unverified_claim && task.executed_calls.empty()) {
    // No evidence at all. Every criterion is Blocked (cannot be
    // evaluated) rather than Failed (we don't have evidence of failure
    // per se, only of missing evidence).
    for (const auto& a : task.acceptance_criteria) {
      r.missing_evidence.push_back(a.id + ": " + a.description +
                                    " (no tool calls produced)");
    }
    r.recommended_action = "retry";
    r.overall_passed = false;
    r.cause = "model asserted success without producing any tool-call "
              "evidence; cannot verify acceptance criteria";
    log_.log(WorkflowEventKind::VerificationFinished, "Verifying",
             task.id + ": missing evidence",
             {{"missing", std::to_string(r.missing_evidence.size())},
              {"attempts", std::to_string(task.attempts)},
              {"retries_remaining",
               std::to_string(task.retries_remaining())}});
    return r;
  }

  if (any_failed_call) {
    // Evidence of failure: tool calls failed. Required criteria are
    // Failed; optional ones are Blocked.
    for (const auto& a : task.acceptance_criteria) {
      r.failed_criteria.push_back(a.id + ": " + a.description);
    }
    r.recommended_action = "retry";
    r.overall_passed = false;
    r.cause = "one or more tool calls failed during execution";
    log_.log(WorkflowEventKind::VerificationFinished, "Verifying",
             task.id + ": failed (tool errors)",
             {{"failed", std::to_string(r.failed_criteria.size())}});
    return r;
  }

  // Default: pass all criteria. (Production code would call model adapter
  // or run real tests; spec §7 explicitly distinguishes "verified" from
  // "model asserted".) Even with successful tool calls we are deliberately
  // conservative: only mark criteria as Passed if the task also has
  // evidence (executed_calls non-empty) OR has no acceptance criteria.
  if (task.acceptance_criteria.empty()) {
    r.overall_passed = true;
    r.recommended_action = "pass";
    r.cause = "task has no acceptance criteria; default-pass";
    log_.log(WorkflowEventKind::VerificationFinished, "Verifying",
             task.id + ": passed (no criteria)");
    return r;
  }
  if (!task.executed_calls.empty() && !any_failed_call) {
    // Successful tool calls exist; verifier treats them as evidence
    // (mock verifier's permissive default). A real verifier would
    // inspect the outputs against each criterion's specific claim.
    for (const auto& a : task.acceptance_criteria) {
      r.passed_criteria.push_back(a.id + ": " + a.description);
    }
    r.overall_passed = true;
    r.recommended_action = "pass";
    r.cause = "tool calls succeeded; criteria considered satisfied";
    log_.log(WorkflowEventKind::VerificationFinished, "Verifying",
             task.id + ": passed",
             {{"passed", std::to_string(r.passed_criteria.size())}});
    return r;
  }

  // No tool calls, no unverified claim, no criteria — fallthrough shouldn't
  // normally happen, but be conservative.
  r.overall_passed = false;
  r.recommended_action = "retry";
  r.cause = "no evidence available";
  return r;
}

/// Apply a verification result onto a PlanTask by setting each
/// acceptance criterion's status field. This is the ONLY place criteria
/// transition out of Defined. Spec §1: criteria must not be marked Passed
/// before verification.
void apply_verification_to_task(PlanTask& task,
                                 const VerificationResult& vr) {
  for (auto& a : task.acceptance_criteria) {
    if (!vr.missing_evidence.empty()) {
      a.status = a.required ? CriterionStatus::Blocked
                            : CriterionStatus::Skipped;
    } else if (!vr.failed_criteria.empty()) {
      a.status = a.required ? CriterionStatus::Failed
                            : CriterionStatus::Skipped;
    } else if (vr.overall_passed) {
      a.status = CriterionStatus::Passed;
    } else {
      a.status = CriterionStatus::Blocked;
    }
  }
}

}  // namespace agent_engine
