// RecoveryManager.h
//
// Spec §7 (recovery): distinct from verification. Handles tool failures,
// invalid model responses, failed tests, repeated errors, missing
// dependencies, blocked tasks, incomplete plans, retry exhaustion,
// interrupted execution.
//
// Bounded retries: "avoid repeating an identical failing action indefinitely."
// If the plan needs to change materially, generates a revision and applies
// the configured approval policy (bounce back to AwaitingApproval).

#ifndef AGENT_ENGINE_CORE_EXECUTION_RECOVERY_MANAGER_H
#define AGENT_ENGINE_CORE_EXECUTION_RECOVERY_MANAGER_H

#include "core/models/DomainModels.h"
#include "core/artifacts/EventLog.h"
#include "ResultVerifier.h"

#include <string>

namespace agent_engine {

enum class RecoveryAction {
  RetryTask,
  BlockTask,
  FailTask,
  FailWorkflow,
  RevisePlan,
  SkipTask,
};

struct RecoveryDecision {
  RecoveryAction action;
  std::string reason;     // human-readable summary, includes retry accounting
  std::string cause;       // underlying verification failure summary
  /// When action == RevisePlan, the manager produces a minimal revised plan
  /// by bumping the plan version + removing the offending task's
  /// dependencies. Real revision would call PlanCoordinator::request_revision.
  /// Empty otherwise.
  std::string proposed_plan_id;
};

class RecoveryManager {
 public:
  RecoveryManager(EventLog& log, const ResultVerifier& verifier);

  /// Decide what to do given a task that just failed verification or
  /// execution. The task's `attempts` and `max_retries` bound the recovery.
  RecoveryDecision diagnose(const TaskPlan& plan,
                              const PlanTask& task,
                              const VerificationResult& verification);

  /// Apply a recovery decision to the plan (mutates task status, may bump
  /// plan version + emit PlanRevised event for material changes).
  void apply(TaskPlan& plan, const PlanTask& task,
              const RecoveryDecision& decision);

 private:
  EventLog& log_;
  const ResultVerifier& verifier_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_EXECUTION_RECOVERY_MANAGER_H
