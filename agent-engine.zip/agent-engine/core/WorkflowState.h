// WorkflowState.h
//
// Workflow state machine per spec section 8. Valid transitions are
// centralized here; no other component may mutate WorkflowState directly
// except WorkflowController (friend).

#ifndef AGENT_ENGINE_CORE_WORKFLOW_STATE_H
#define AGENT_ENGINE_CORE_WORKFLOW_STATE_H

#include <string>
#include <vector>

namespace agent_engine {

enum class WorkflowState {
  Draft,
  Planning,
  AwaitingClarification,
  AwaitingApproval,
  Executing,
  Verifying,
  Recovering,
  Blocked,
  Paused,
  Completed,
  Cancelled,
  Failed,
};

/// String name for logging / markdown rendering.
const char* workflow_state_name(WorkflowState s);

/// True if `from -> to` is a legal transition per spec section 8.
bool is_valid_transition(WorkflowState from, WorkflowState to);

/// Pretty-print all legal transitions; useful for tests and docs.
std::string workflow_state_diagram();

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_WORKFLOW_STATE_H
