// AgentEngine.h
//
// Top-level orchestrator. Wires together:
//   - WorkflowController (state machine)
//   - PlanCoordinator (interactive planning)
//   - AgentLoop (execution)
//   - ToolDispatcher / ToolRegistry
//   - ResultVerifier + RecoveryManager (verification & recovery)
//   - MarkdownRenderer + ProgressTracker (artifacts)
//   - IPlanRepository (resumability)
//
// Spec §13 Phase 7: connect the framework to the existing model
// implementation and run the full test suite.

#ifndef AGENT_ENGINE_CORE_AGENT_ENGINE_H
#define AGENT_ENGINE_CORE_AGENT_ENGINE_H

#include "core/WorkflowState.h"
#include "core/WorkflowController.h"
#include "core/models/DomainModels.h"
#include "core/planning/PlanCoordinator.h"
#include "core/execution/AgentLoop.h"
#include "core/execution/ResultVerifier.h"
#include "core/execution/RecoveryManager.h"
#include "core/tools/IModelAdapter.h"
#include "core/tools/ToolRegistry.h"
#include "core/execution/ToolDispatcher.h"
#include "core/execution/TaskScheduler.h"
#include "core/artifacts/MarkdownRenderer.h"
#include "core/artifacts/ProgressTracker.h"
#include "core/artifacts/EventLog.h"
#include "core/storage/IPlanRepository.h"

#include <memory>
#include <string>

namespace agent_engine {

class AgentEngine {
 public:
  /// `adapter` is owned by the engine (a small per-engine object).
  /// `repo` is non-owning; the caller is responsible for keeping it alive
  /// for the engine's lifetime. This allows tests to share a single
  /// repository across multiple engine instances for resumability scenarios.
  AgentEngine(std::unique_ptr<IModelAdapter> adapter, IPlanRepository& repo);

  // ---- User-facing operations -------------------------------------------

  /// Start a new workflow from a user request. Returns the workflow id
  /// (== request id). Transitions Draft → Planning → (AwaitingClarification
  /// | AwaitingApproval).
  std::string submit_request(const UserRequest& req);

  /// Inspect / edit / approve / reject the current plan.
  const TaskPlan& current_plan() const { return plan_; }
  TaskPlan& mutable_plan() { return plan_; }

  /// Apply user edits (add/remove/change-priority/edit-description/
  /// add-dep/remove-dep). Returns per-edit outcome.
  EditOutcome edit_plan(const PlanEdit& edit);

  /// Approve the current plan. Transitions to Executing.
  /// Returns false if the workflow is not in AwaitingApproval.
  bool approve_plan();

  /// Reject the plan and request a revision. Stays in Planning.
  /// Returns the revised plan (also accessible via current_plan()).
  const TaskPlan& reject_plan_and_revise(const std::string& reason,
                                            const std::string& note);

  /// Answer a clarifying question. Transitions AwaitingClarification →
  /// AwaitingApproval (via Planning). Returns false if not in the right
  /// state.
  bool answer_clarification(const std::string& answer);

  /// Run one step of the workflow. Returns true if the workflow is still
  /// running; false once terminal. This is the main entry point for a
  /// test / demo driver that wants step-by-step control.
  bool step();

  /// Run the workflow to completion or terminal state.
  /// Bounded by an internal max-step guard.
  enum class RunResult { Completed, Cancelled, Failed, Blocked, Stalled };
  RunResult run();

  /// Cancel the workflow.
  void cancel(const std::string& reason);

  // ---- Inspection / artifacts ------------------------------------------

  WorkflowState state() const { return controller_.state(); }

  /// Render the three markdown views from the current structured state.
  /// Spec §9: these are views, not the source of truth.
  std::string render_task_plan_md() const;
  std::string render_findings_md() const;
  std::string render_progress_md() const;

  /// Save the current workflow snapshot for resumability.
  void checkpoint(const std::string& workflow_id);

  /// Resume a workflow from a repository snapshot.
  /// Spec §10: "Do not automatically repeat a non-idempotent action if its
  /// previous outcome is unknown." Resume re-loads state + replays events
  /// but does NOT re-run any task whose previous outcome is known.
  bool resume(const std::string& workflow_id);

  // ---- Component accessors (for tests) ---------------------------------

  EventLog& event_log() { return log_; }
  ToolRegistry& tool_registry() { return registry_; }
  PlanCoordinator& coordinator() { return *coordinator_; }
  AgentLoop& agent_loop() { return *loop_; }
  ResultVerifier& verifier() { return *verifier_; }
  RecoveryManager& recovery() { return *recovery_; }
  IModelAdapter& model_adapter() { return *adapter_; }

 private:
  // Owned infra.
  EventLog log_;
  std::unique_ptr<IModelAdapter> adapter_;  // owned
  IPlanRepository& repo_;                    // non-owning
  ToolRegistry registry_;
  std::unique_ptr<RequestAnalyzer> ra_;
  std::unique_ptr<ContextAnalyzer> ca_;
  std::unique_ptr<TaskDecomposer> td_;
  std::unique_ptr<PlanValidator> pv_;
  std::unique_ptr<PlanCoordinator> coordinator_;
  std::unique_ptr<ResultVerifier> verifier_;
  std::unique_ptr<RecoveryManager> recovery_;
  std::unique_ptr<ToolDispatcher> dispatcher_;
  std::unique_ptr<TaskScheduler> scheduler_;
  std::unique_ptr<AgentLoop> loop_;
  std::unique_ptr<MarkdownRenderer> renderer_;
  WorkflowController controller_;

  // Per-workflow mutable state.
  UserRequest original_request_;
  TaskPlan plan_;
  std::string workflow_id_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_AGENT_ENGINE_H
