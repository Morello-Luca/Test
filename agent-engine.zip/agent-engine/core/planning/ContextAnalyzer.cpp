// ContextAnalyzer.cpp

#include "ContextAnalyzer.h"

namespace agent_engine {

ProjectContext ContextAnalyzer::analyze(const std::string& /*user_text*/) const {
  ProjectContext c;
  c.relevant_files = files_;
  c.conventions = conventions_;
  c.known_facts = facts_;
  return c;
}

}  // namespace agent_engine
