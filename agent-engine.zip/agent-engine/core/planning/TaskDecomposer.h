// TaskDecomposer.h
//
// Spec §4.2 / §4.4: produces a structured plan (overall goal, milestones,
// tasks, dependencies, acceptance criteria, risks, assumptions, verification
// strategy). The decomposer is rule-based and scriptable for tests.

#ifndef AGENT_ENGINE_CORE_PLANNING_TASK_DECOMPOSER_H
#define AGENT_ENGINE_CORE_PLANNING_TASK_DECOMPOSER_H

#include "core/models/DomainModels.h"
#include "RequestAnalyzer.h"
#include "ContextAnalyzer.h"

#include <functional>
#include <string>
#include <vector>

namespace agent_engine {

class TaskDecomposer {
 public:
  using DecomposeFn =
      std::function<TaskPlan(const UserRequest&,
                              const RequestAnalysis&,
                              const ProjectContext&)>;

  /// Default heuristic decomposer; produces a single milestone with one or
  /// more tasks based on key verbs in the user text. Production code would
  /// use the model adapter instead.
  TaskPlan decompose(const UserRequest& req,
                      const RequestAnalysis& analysis,
                      const ProjectContext& ctx) const;

  /// Test hook: override the decomposition function entirely.
  void set_decompose_fn(DecomposeFn fn) { fn_ = std::move(fn); }

 private:
  DecomposeFn fn_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_PLANNING_TASK_DECOMPOSER_H
