// RequestAnalyzer.h
//
// Spec §4.1 / §4.4: analyzes the original request to identify intent,
// explicit requirements, missing information / ambiguities, assumptions.
// Ambiguity analysis is folded into RequestAnalyzer because there is no
// meaningful independent logic to justify a separate AmbiguityDetector class
// (spec §2.1 / §4.4 — "Otherwise, ambiguity analysis may initially belong to
// RequestAnalyzer").

#ifndef AGENT_ENGINE_CORE_PLANNING_REQUEST_ANALYZER_H
#define AGENT_ENGINE_CORE_PLANNING_REQUEST_ANALYZER_H

#include "core/models/DomainModels.h"

#include <string>
#include <vector>

namespace agent_engine {

struct RequestAnalysis {
  std::string user_text;
  std::string intent_summary;
  std::vector<std::string> explicit_requirements;
  std::vector<std::string> missing_info;        // ambiguities identified
  std::vector<std::string> assumptions;
  std::vector<std::string> clarifying_questions;  // only when material

  bool needs_clarification() const { return !clarifying_questions.empty(); }
};

class RequestAnalyzer {
 public:
  /// Heuristic, deterministic analysis. Tests can inject custom analyses via
  /// `script_analysis`.
  RequestAnalysis analyze(const UserRequest& req) const;

  /// Test hook: script a canned analysis for a specific request id.
  void script_analysis(const std::string& request_id, RequestAnalysis a);

 private:
  std::vector<std::pair<std::string, RequestAnalysis>> scripted_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_PLANNING_REQUEST_ANALYZER_H
