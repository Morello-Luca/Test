// PlanValidator.h
//
// Spec §4.4 / §7: validates plans before approval and during verification.
// Checks: DAG (no cycles), dependency completeness, every task has stable
// id + acceptance criteria, no duplicate ids.

#ifndef AGENT_ENGINE_CORE_PLANNING_PLAN_VALIDATOR_H
#define AGENT_ENGINE_CORE_PLANNING_PLAN_VALIDATOR_H

#include "core/models/DomainModels.h"

#include <string>
#include <vector>

namespace agent_engine {

struct PlanValidationResult {
  bool ok = false;
  std::vector<std::string> errors;
  std::vector<std::string> warnings;
};

class PlanValidator {
 public:
  PlanValidationResult validate(const TaskPlan& p) const;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_PLANNING_PLAN_VALIDATOR_H
