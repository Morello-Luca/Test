// RequestAnalyzer.cpp

#include "RequestAnalyzer.h"

#include <algorithm>

namespace agent_engine {

namespace {

// Trivial heuristic: scan the user's text for ambiguity markers. A real
// implementation would route the request through the model adapter and parse
// a structured response. Per spec §4.1: "Do not force unnecessary
// clarification for straightforward tasks."
bool looks_unambiguous(const std::string& text) {
  // Cheap signal: question marks in the user's request are a strong ambiguity
  // signal in this domain ("what about X?", "should we Y?").
  if (text.find('?') != std::string::npos) return false;
  return true;
}

}  // namespace

RequestAnalysis RequestAnalyzer::analyze(const UserRequest& req) const {
  for (const auto& [id, a] : scripted_) {
    if (id == req.id) return a;
  }

  RequestAnalysis a;
  a.user_text = req.user_text;
  a.intent_summary = "User wants: " + req.user_text;

  // Pull any extra context into assumptions.
  for (const auto& [k, v] : req.extra_context) {
    a.assumptions.push_back(k + " = " + v);
  }

  if (!looks_unambiguous(req.user_text)) {
    a.missing_info.push_back("Question in user text suggests ambiguity.");
    a.clarifying_questions.push_back(
        "Could you restate the goal as an imperative so the plan can target "
        "a concrete deliverable?");
  }
  return a;
}

void RequestAnalyzer::script_analysis(const std::string& request_id,
                                       RequestAnalysis a) {
  scripted_.emplace_back(request_id, std::move(a));
}

}  // namespace agent_engine
