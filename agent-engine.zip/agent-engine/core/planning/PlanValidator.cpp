// PlanValidator.cpp

#include "PlanValidator.h"

#include <algorithm>
#include <unordered_map>
#include <unordered_set>

namespace agent_engine {

namespace {

// Depth-first cycle check from `start` over the plan's dependency graph.
// `adjacency` maps task id -> list of dependent task ids (i.e., reverse
// direction of dependencies).
bool has_cycle_from(const std::string& start,
                     const std::unordered_map<std::string,
                       std::vector<std::string>>& adjacency,
                     std::unordered_set<std::string>& visited,
                     std::unordered_set<std::string>& on_stack) {
  visited.insert(start);
  on_stack.insert(start);
  auto it = adjacency.find(start);
  if (it != adjacency.end()) {
    for (const auto& nbr : it->second) {
      if (on_stack.count(nbr)) return true;
      if (!visited.count(nbr)) {
        if (has_cycle_from(nbr, adjacency, visited, on_stack)) return true;
      }
    }
  }
  on_stack.erase(start);
  return false;
}

}  // namespace

PlanValidationResult PlanValidator::validate(const TaskPlan& p) const {
  PlanValidationResult r;
  if (p.tasks.empty()) {
    r.errors.push_back("Plan has no tasks.");
    r.ok = false;
    return r;
  }
  if (p.overall_goal.empty()) {
    r.errors.push_back("Plan has empty overall_goal.");
  }

  // 1. Id uniqueness + non-empty ids.
  std::unordered_set<std::string> seen;
  for (const auto& t : p.tasks) {
    if (t.id.empty()) {
      r.errors.push_back("Plan task with empty id.");
      continue;
    }
    if (!seen.insert(t.id).second) {
      r.errors.push_back("Duplicate task id: " + t.id);
    }
  }
  // 2. Title + description non-empty.
  for (const auto& t : p.tasks) {
    if (t.title.empty()) r.errors.push_back("Task " + t.id + " missing title.");
    if (t.description.empty()) {
      r.warnings.push_back("Task " + t.id + " missing description.");
    }
    if (t.acceptance_criteria.empty()) {
      r.warnings.push_back(
        "Task " + t.id + " has no acceptance criteria (spec §7).");
    }
    if (t.max_retries < 0) r.errors.push_back(
        "Task " + t.id + " has negative max_retries.");
  }
  // 3. Dependency references must exist.
  std::unordered_set<std::string> ids;
  for (const auto& t : p.tasks) ids.insert(t.id);
  for (const auto& t : p.tasks) {
    for (const auto& d : t.dependencies) {
      if (!ids.count(d)) {
        r.errors.push_back("Task " + t.id + " depends on unknown id " + d);
      }
    }
  }
  // 4. Cycle detection. adjacency maps task -> dependents.
  std::unordered_map<std::string, std::vector<std::string>> adjacency;
  for (const auto& t : p.tasks) {
    for (const auto& d : t.dependencies) adjacency[d].push_back(t.id);
  }
  std::unordered_set<std::string> visited, on_stack;
  for (const auto& t : p.tasks) {
    if (!visited.count(t.id)) {
      if (has_cycle_from(t.id, adjacency, visited, on_stack)) {
        r.errors.push_back("Plan dependency graph contains a cycle.");
        break;
      }
    }
  }

  r.ok = r.errors.empty();
  return r;
}

}  // namespace agent_engine
