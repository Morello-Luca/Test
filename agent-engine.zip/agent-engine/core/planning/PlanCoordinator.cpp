// PlanCoordinator.cpp

#include "PlanCoordinator.h"

#include <algorithm>
#include <chrono>
#include <ctime>
#include <sstream>
#include <unordered_set>

namespace agent_engine {

namespace {

std::string iso_now() {
  using std::chrono::system_clock;
  auto now = system_clock::now();
  std::time_t t = system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&t, &tm);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
  return std::string(buf);
}

void bump_version(TaskPlan& p) {
  ++p.version;
  p.updated_at_iso = iso_now();
}

void clean_dependencies(TaskPlan& p, const std::string& removed_id) {
  for (auto& t : p.tasks) {
    auto& d = t.dependencies;
    d.erase(std::remove(d.begin(), d.end(), removed_id), d.end());
  }
}

}  // namespace

PlanCoordinator::PlanCoordinator(EventLog& log,
                                   std::unique_ptr<RequestAnalyzer> ra,
                                   std::unique_ptr<ContextAnalyzer> ca,
                                   std::unique_ptr<TaskDecomposer> td,
                                   std::unique_ptr<PlanValidator> pv)
    : log_(log),
      ra_(std::move(ra)),
      ca_(std::move(ca)),
      td_(std::move(td)),
      pv_(std::move(pv)) {}

RequestAnalysis PlanCoordinator::analyze_request(const UserRequest& req) {
  auto a = ra_->analyze(req);
  if (a.needs_clarification()) {
    log_.log(WorkflowEventKind::ClarificationRequested,
             "AwaitingClarification",
             "missing info: " + std::to_string(a.clarifying_questions.size()) +
             " questions",
             {{"first_q", a.clarifying_questions.empty() ? "" :
                              a.clarifying_questions[0]}});
  }
  return a;
}

TaskPlan PlanCoordinator::produce_draft_plan(const UserRequest& req) {
  auto analysis = ra_->analyze(req);
  auto context = ca_->analyze(req.user_text);
  TaskPlan plan = td_->decompose(req, analysis, context);
  plan.missing_info = analysis.missing_info;
  plan.assumptions = analysis.assumptions;
  log_.log(WorkflowEventKind::PlanCreated, "Planning",
           "draft plan v" + std::to_string(plan.version),
           {{"plan_id", plan.plan_id}, {"tasks",
            std::to_string(plan.tasks.size())}});
  return plan;
}

PlanValidationResult PlanCoordinator::validate(const TaskPlan& p) const {
  return pv_->validate(p);
}

EditOutcome PlanCoordinator::apply_edit(TaskPlan& plan, const PlanEdit& edit) {
  switch (edit.op) {
    case PlanEdit::EditDescription: {
      auto* t = plan.find_task(edit.task_id);
      if (!t) return EditOutcome::RejectedUnknownTask;
      if (t->description == edit.description) return EditOutcome::RejectedNoChange;
      t->description = edit.description;
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               "edited description of " + edit.task_id);
      return EditOutcome::Applied;
    }
    case PlanEdit::AddTask: {
      PlanTask nt = edit.new_task;
      if (nt.id.empty()) nt.id = "task_" + std::to_string(plan.tasks.size() + 1);
      // Validate dependencies exist.
      std::unordered_set<TaskId> ids;
      for (const auto& t : plan.tasks) ids.insert(t.id);
      for (const auto& d : nt.dependencies) {
        if (!ids.count(d)) return EditOutcome::RejectedInvalidDependency;
      }
      plan.tasks.push_back(nt);
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               "added task " + nt.id);
      return EditOutcome::Applied;
    }
    case PlanEdit::RemoveTask: {
      auto it = std::find_if(plan.tasks.begin(), plan.tasks.end(),
                              [&](const PlanTask& t) { return t.id == edit.task_id; });
      if (it == plan.tasks.end()) return EditOutcome::RejectedUnknownTask;
      plan.tasks.erase(it);
      clean_dependencies(plan, edit.task_id);
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               "removed task " + edit.task_id);
      return EditOutcome::Applied;
    }
    case PlanEdit::ChangePriority: {
      // Simple ordering change: move the task to position edit.new_priority.
      auto it = std::find_if(plan.tasks.begin(), plan.tasks.end(),
                              [&](const PlanTask& t) { return t.id == edit.task_id; });
      if (it == plan.tasks.end()) return EditOutcome::RejectedUnknownTask;
      PlanTask t = *it;
      plan.tasks.erase(it);
      int pos = std::max(0, std::min(edit.new_priority,
                                       static_cast<int>(plan.tasks.size())));
      plan.tasks.insert(plan.tasks.begin() + pos, t);
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               "reordered " + edit.task_id);
      return EditOutcome::Applied;
    }
    case PlanEdit::AddDependency: {
      auto* t = plan.find_task(edit.task_id);
      if (!t) return EditOutcome::RejectedUnknownTask;
      // Validate dep_id exists in the plan.
      if (!plan.find_task(edit.dep_id)) return EditOutcome::RejectedInvalidDependency;
      // Avoid cycles and duplicates.
      if (std::find(t->dependencies.begin(), t->dependencies.end(), edit.dep_id)
          != t->dependencies.end()) return EditOutcome::RejectedNoChange;
      t->dependencies.push_back(edit.dep_id);
      // Re-validate the plan; reject if a cycle was introduced.
      if (!pv_->validate(plan).ok) {
        t->dependencies.pop_back();
        return EditOutcome::RejectedInvalidDependency;
      }
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               edit.task_id + " -> " + edit.dep_id);
      return EditOutcome::Applied;
    }
    case PlanEdit::RemoveDependency: {
      auto* t = plan.find_task(edit.task_id);
      if (!t) return EditOutcome::RejectedUnknownTask;
      auto& d = t->dependencies;
      auto it = std::find(d.begin(), d.end(), edit.dep_id);
      if (it == d.end()) return EditOutcome::RejectedNoChange;
      d.erase(it);
      bump_version(plan);
      log_.log(WorkflowEventKind::PlanRevised, "AwaitingApproval",
               "removed dep " + edit.task_id + " <- " + edit.dep_id);
      return EditOutcome::Applied;
    }
  }
  return EditOutcome::RejectedNoChange;
}

void PlanCoordinator::approve(TaskPlan& plan) {
  plan.approved = true;
  bump_version(plan);
  log_.log(WorkflowEventKind::PlanApproved, "AwaitingApproval",
           "plan v" + std::to_string(plan.version) + " approved");
}

void PlanCoordinator::reject(TaskPlan& plan, const std::string& reason) {
  bump_version(plan);
  log_.log(WorkflowEventKind::PlanRejected, "Planning",
           "plan rejected: " + reason);
}

TaskPlan PlanCoordinator::request_revision(const TaskPlan& current,
                                             const UserRequest& req,
                                             const std::string& user_note) {
  UserRequest revised = req;
  if (!user_note.empty()) revised.extra_context["revision_note"] = user_note;
  auto analysis = ra_->analyze(revised);
  auto context = ca_->analyze(revised.user_text);
  TaskPlan next = td_->decompose(revised, analysis, context);
  next.version = current.version + 1;
  next.plan_id = current.plan_id;  // same plan, new revision
  next.created_at_iso = current.created_at_iso;
  next.updated_at_iso = iso_now();
  next.approval_policy = current.approval_policy;
  next.approved = false;
  log_.log(WorkflowEventKind::PlanRevised, "Planning",
           "revised plan to v" + std::to_string(next.version));
  return next;
}

}  // namespace agent_engine
