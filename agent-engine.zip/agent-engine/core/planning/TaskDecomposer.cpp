// TaskDecomposer.cpp

#include "TaskDecomposer.h"

#include <algorithm>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace agent_engine {

namespace {

std::string iso_now() {
  using std::chrono::system_clock;
  auto now = system_clock::now();
  std::time_t t = system_clock::to_time_t(now);
  std::tm tm{};
  gmtime_r(&t, &tm);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
  return std::string(buf);
}

std::string new_id(const std::string& prefix, int n) {
  std::ostringstream os;
  os << prefix << "_" << std::setw(2) << std::setfill('0') << n;
  return os.str();
}

}  // namespace

TaskPlan TaskDecomposer::decompose(const UserRequest& req,
                                    const RequestAnalysis& analysis,
                                    const ProjectContext& ctx) const {
  if (fn_) return fn_(req, analysis, ctx);

  TaskPlan p;
  p.request_id = req.id;
  // Plan id is timestamped for uniqueness in the absence of a real UUID.
  p.plan_id = "plan_" + iso_now();
  p.version = 0;
  p.created_at_iso = iso_now();
  p.updated_at_iso = p.created_at_iso;

  p.overall_goal = analysis.intent_summary;
  p.milestones = {"Implement", "Verify"};
  p.assumptions = analysis.assumptions;
  p.missing_info = analysis.missing_info;

  // Trivial decomposition: two tasks based on the milestones. Real impl
  // would invoke the model adapter to get a richer structure.
  PlanTask t1;
  t1.id = new_id("task", 1);
  t1.title = "Implement";
  t1.description = "Implement the requested work per the user's intent.";
  t1.status = TaskStatus::Pending;
  t1.acceptance_criteria = {
    {"ac1", "Implementation matches user's stated intent.", true},
    {"ac2", "No syntax errors in produced artifacts.", true},
  };
  t1.max_retries = 2;

  PlanTask t2;
  t2.id = new_id("task", 2);
  t2.title = "Verify";
  t2.description = "Verify implementation against acceptance criteria.";
  t2.status = TaskStatus::Pending;
  t2.dependencies = {t1.id};
  t2.acceptance_criteria = {
    {"ac1", "All acceptance criteria from task 1 pass.", true},
  };
  t2.max_retries = 2;

  p.tasks = {t1, t2};

  p.risks = {"Insufficient detail in user request."};
  return p;
}

}  // namespace agent_engine
