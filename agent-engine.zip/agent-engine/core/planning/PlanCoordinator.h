// PlanCoordinator.h
//
// Spec §4.4: composes request analysis, context analysis, task decomposition
// and plan validation. It does NOT implement every analysis algorithm itself
// — it delegates to RequestAnalyzer, ContextAnalyzer, TaskDecomposer,
// PlanValidator.
//
// Also owns the editing / revision surface (spec §4.3: approve, reject, edit,
// revise, add/remove tasks, change priorities, request revised plan).

#ifndef AGENT_ENGINE_CORE_PLANNING_PLAN_COORDINATOR_H
#define AGENT_ENGINE_CORE_PLANNING_PLAN_COORDINATOR_H

#include "core/models/DomainModels.h"
#include "core/artifacts/EventLog.h"
#include "RequestAnalyzer.h"
#include "ContextAnalyzer.h"
#include "TaskDecomposer.h"
#include "PlanValidator.h"

#include <memory>
#include <string>
#include <vector>

namespace agent_engine {

enum class EditOutcome {
  Applied,
  RejectedUnknownTask,
  RejectedInvalidDependency,
  RejectedNoChange,
};

struct PlanEdit {
  // Edit operations supported by the user-facing editor (spec §4.3).
  enum Op {
    EditDescription,         // change task.description
    AddTask,                 // push new task
    RemoveTask,              // remove existing task + clean up deps
    ChangePriority,          // re-order tasks / change priorities
    AddDependency,           // t2 depends on t1
    RemoveDependency,
  };
  Op op;
  std::string task_id;       // target task (or empty for AddTask)
  PlanTask new_task;         // populated for AddTask
  std::string description;  // populated for EditDescription
  std::string dep_id;         // populated for AddDependency/RemoveDependency
  int new_priority = 0;      // populated for ChangePriority
};

class PlanCoordinator {
 public:
  PlanCoordinator(EventLog& log,
                   std::unique_ptr<RequestAnalyzer> ra,
                   std::unique_ptr<ContextAnalyzer> ca,
                   std::unique_ptr<TaskDecomposer> td,
                   std::unique_ptr<PlanValidator> pv);

  // Phase 1: produce an analysis + draft plan for the user's request.
  // Sets WorkflowState::AwaitingClarification if missing_info is material.
  RequestAnalysis analyze_request(const UserRequest& req);
  TaskPlan produce_draft_plan(const UserRequest& req);

  // Phase 2: validate the draft plan.
  PlanValidationResult validate(const TaskPlan& p) const;

  // Phase 3 (spec §4.3): user-facing editing.
  // Each edit bumps `plan.version` and updates `updated_at_iso`.
  EditOutcome apply_edit(TaskPlan& plan, const PlanEdit& edit);

  // Phase 4 (spec §4.3): user approves / rejects / requests revision.
  void approve(TaskPlan& plan);
  void reject(TaskPlan& plan, const std::string& reason);

  // Revisions are produced by re-running TaskDecomposer with the same
  // analysis + context but optionally an additional user note.
  TaskPlan request_revision(const TaskPlan& current,
                              const UserRequest& req,
                              const std::string& user_note);

  // Convenience accessors.
  RequestAnalyzer& request_analyzer() { return *ra_; }
  ContextAnalyzer& context_analyzer() { return *ca_; }
  TaskDecomposer& task_decomposer() { return *td_; }
  PlanValidator& plan_validator() { return *pv_; }

 private:
  EventLog& log_;
  std::unique_ptr<RequestAnalyzer> ra_;
  std::unique_ptr<ContextAnalyzer> ca_;
  std::unique_ptr<TaskDecomposer> td_;
  std::unique_ptr<PlanValidator> pv_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_PLANNING_PLAN_COORDINATOR_H
