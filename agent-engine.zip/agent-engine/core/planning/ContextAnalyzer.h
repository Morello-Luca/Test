// ContextAnalyzer.h
//
// Spec §4.1 / §4.4: gathers relevant project context that the plan must
// respect (existing files, conventions, current state). Implemented here as
// a pluggable, in-memory only analyzer; a real implementation would scan
// the source tree via the LocalFileTool (Phase 4).

#ifndef AGENT_ENGINE_CORE_PLANNING_CONTEXT_ANALYZER_H
#define AGENT_ENGINE_CORE_PLANNING_CONTEXT_ANALYZER_H

#include <map>
#include <string>
#include <vector>

namespace agent_engine {

struct ProjectContext {
  std::vector<std::string> relevant_files;
  std::vector<std::string> conventions;
  std::map<std::string, std::string> known_facts;  // name -> value
};

class ContextAnalyzer {
 public:
  void add_known_fact(const std::string& k, const std::string& v) {
    facts_[k] = v;
  }
  void add_convention(const std::string& c) {
    conventions_.push_back(c);
  }
  void add_relevant_file(const std::string& path) {
    files_.push_back(path);
  }

  ProjectContext analyze(const std::string& user_text) const;

 private:
  std::vector<std::string> files_;
  std::vector<std::string> conventions_;
  std::map<std::string, std::string> facts_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_PLANNING_CONTEXT_ANALYZER_H
