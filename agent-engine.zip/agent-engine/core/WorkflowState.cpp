// WorkflowState.cpp

#include "WorkflowState.h"

#include <sstream>
#include <stdexcept>

namespace agent_engine {

const char* workflow_state_name(WorkflowState s) {
  switch (s) {
    case WorkflowState::Draft:                  return "Draft";
    case WorkflowState::Planning:               return "Planning";
    case WorkflowState::AwaitingClarification:  return "AwaitingClarification";
    case WorkflowState::AwaitingApproval:       return "AwaitingApproval";
    case WorkflowState::Executing:               return "Executing";
    case WorkflowState::Verifying:              return "Verifying";
    case WorkflowState::Recovering:              return "Recovering";
    case WorkflowState::Blocked:                 return "Blocked";
    case WorkflowState::Paused:                  return "Paused";
    case WorkflowState::Completed:               return "Completed";
    case WorkflowState::Cancelled:               return "Cancelled";
    case WorkflowState::Failed:                   return "Failed";
  }
  return "?";
}

bool is_valid_transition(WorkflowState from, WorkflowState to) {
  if (from == to) return false;  // no-op transitions are not "valid" here
  switch (from) {
    case WorkflowState::Draft:
      return to == WorkflowState::Planning ||
             to == WorkflowState::Cancelled;
    case WorkflowState::Planning:
      return to == WorkflowState::AwaitingClarification ||
             to == WorkflowState::AwaitingApproval ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::Failed;
    case WorkflowState::AwaitingClarification:
      return to == WorkflowState::Planning ||
             to == WorkflowState::AwaitingApproval ||
             to == WorkflowState::Cancelled;
    case WorkflowState::AwaitingApproval:
      return to == WorkflowState::Executing ||
             to == WorkflowState::Planning ||       // revision requested
             to == WorkflowState::Cancelled ||
             to == WorkflowState::Failed;
    case WorkflowState::Executing:
      return to == WorkflowState::Verifying ||
             to == WorkflowState::Paused ||
             to == WorkflowState::Recovering ||
             to == WorkflowState::Blocked ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::Failed ||
             to == WorkflowState::Completed;
    case WorkflowState::Verifying:
      return to == WorkflowState::Executing ||      // continue next task
             to == WorkflowState::Recovering ||
             to == WorkflowState::Blocked ||
             to == WorkflowState::Completed ||
             to == WorkflowState::Failed ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::Paused;
    case WorkflowState::Recovering:
      return to == WorkflowState::Executing ||
             to == WorkflowState::Verifying ||
             to == WorkflowState::Blocked ||
             to == WorkflowState::Failed ||
             to == WorkflowState::Paused ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::AwaitingApproval;  // material plan change
    case WorkflowState::Blocked:
      return to == WorkflowState::Executing ||
             to == WorkflowState::Recovering ||
             to == WorkflowState::Paused ||
             to == WorkflowState::Failed ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::AwaitingApproval;
    case WorkflowState::Paused:
      return to == WorkflowState::Executing ||
             to == WorkflowState::Cancelled ||
             to == WorkflowState::Failed;
    case WorkflowState::Completed:
    case WorkflowState::Cancelled:
    case WorkflowState::Failed:
      // Terminal states; no further transitions.
      return false;
  }
  return false;
}

std::string workflow_state_diagram() {
  std::ostringstream os;
  for (int from_i = 0; from_i <= static_cast<int>(WorkflowState::Failed);
       ++from_i) {
    auto from = static_cast<WorkflowState>(from_i);
    for (int to_i = 0; to_i <= static_cast<int>(WorkflowState::Failed);
         ++to_i) {
      auto to = static_cast<WorkflowState>(to_i);
      if (is_valid_transition(from, to)) {
        os << "  " << workflow_state_name(from) << " -> "
           << workflow_state_name(to) << "\n";
      }
    }
  }
  return os.str();
}

}  // namespace agent_engine
