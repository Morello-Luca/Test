// test_phase1.cpp — Phase 1 smoke test: existing model + adapter boundary.

#include "core/tools/IModelAdapter.h"

#include "existing/ModelConfig.h"
#include "existing/ModelLoader.h"

#include <cassert>
#include <iostream>
#include <memory>

using namespace agent_engine;

static void test_existing_loader_default() {
  existing::ModelLoader loader;
  auto r = loader.infer({}, "");
  assert(r.finish_reason == "stop");
  std::cout << "  [ok] existing::ModelLoader default response\n";
}

static void test_existing_loader_scripted() {
  existing::ModelLoader loader;
  existing::LoaderResponse scripted;
  scripted.content = "hello";
  scripted.finish_reason = "stop";
  loader.push_scripted_response(scripted);
  auto r = loader.infer({}, "");
  assert(r.content == "hello");
  std::cout << "  [ok] existing::ModelLoader scripted response\n";
}

static void test_existing_adapter_translates() {
  existing::ModelLoader loader;
  existing::LoaderResponse scripted;
  scripted.content = "via-existing";
  scripted.finish_reason = "stop";
  loader.push_scripted_response(scripted);

  std::unique_ptr<IModelAdapter> adapter(make_existing_model_adapter(loader));
  auto r = adapter->infer({{"user", "hi"}}, "");
  assert(r.content == "via-existing");
  assert(r.finish_reason == "stop");
  std::cout << "  [ok] ExistingModelAdapter translation works\n";
}

static void test_mock_adapter() {
  std::unique_ptr<IModelAdapter> adapter(make_mock_model_adapter());
  auto r = adapter->infer({}, "");
  assert(r.finish_reason == "stop");
  std::cout << "  [ok] MockModelAdapter returns stop on empty queue\n";
}

int main() {
  std::cout << "[phase1] existing model + adapter boundary\n";
  test_existing_loader_default();
  test_existing_loader_scripted();
  test_existing_adapter_translates();
  test_mock_adapter();
  std::cout << "[phase1] all tests passed\n";
  return 0;
}
