// test_phase7.cpp — Phase 7: end-to-end integration scenarios.
//
// Covers spec §12 required scenarios:
//   - straightforward request (no ambiguity)
//   - request requiring clarification
//   - plan rejection + revision
//   - plan approval + execution
//   - successful tool calls
//   - failed tool calls + bounded retries
//   - failed verification + recovery
//   - task dependency blocking
//   - plan changes during execution
//   - cancellation + iteration limits
//   - interrupted workflow + safe resumption
//   - markdown consistency with structured state
//   - invalid tool arguments + unauthorized operations

#include "core/AgentEngine.h"
#include "core/tools/IModelAdapter.h"
#include "core/tools/LocalFileTool.h"
#include "core/tools/MockTool.h"
#include "existing/ModelLoader.h"
#include "core/models/DomainModels.h"
#include "core/storage/InMemoryPlanRepository.h"

#include <cassert>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

using namespace agent_engine;

// Helper: build an AgentEngine wired to an existing ModelLoader, with a
// single scripted response queue we can prepend to.
//
// (A previous version of this file used a TestHarness struct; the helper
// functions below are simpler and avoid the ownership issues that arose
// when AgentEngine switched to non-owning repository references.)

// Helper: build an engine sharing the given loader + repo. Caller owns both.
static std::unique_ptr<AgentEngine> make_engine_with_loader(
    existing::ModelLoader& loader, IPlanRepository& repo) {
  return std::make_unique<AgentEngine>(
      std::unique_ptr<IModelAdapter>(make_existing_model_adapter(loader)),
      repo);
}

// ---------------------------------------------------------------------------
// Scenario 1: straightforward request — no ambiguity.
// ---------------------------------------------------------------------------

static void test_straightforward_request() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf1", "Add a README.md file.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  assert(engine->state() == WorkflowState::AwaitingApproval);
  std::cout << "  [ok] straightforward request → AwaitingApproval\n";
}

// ---------------------------------------------------------------------------
// Scenario 2: ambiguous request → clarification.
// ---------------------------------------------------------------------------

static void test_clarification_request() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf2", "What about the API? Should it be REST?", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  assert(engine->state() == WorkflowState::AwaitingClarification);
  // Answer clarification → goes back to AwaitingApproval.
  assert(engine->answer_clarification("REST"));
  assert(engine->state() == WorkflowState::AwaitingApproval);
  std::cout << "  [ok] clarification flow works\n";
}

// ---------------------------------------------------------------------------
// Scenario 3: plan rejection + revision.
// ---------------------------------------------------------------------------

static void test_plan_reject_and_revise() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf3", "Write a unit test.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  auto v_before = engine->current_plan().version;
  engine->reject_plan_and_revise("too coarse", "split into smaller tasks");
  // reject bumps version once; request_revision uses (current.version + 1)
  // for the new plan's version. So the final version is strictly greater
  // than v_before (specifically v_before + 2).
  assert(engine->current_plan().version > v_before);
  assert(engine->state() == WorkflowState::AwaitingApproval);
  std::cout << "  [ok] plan rejected + revised\n";
}

// ---------------------------------------------------------------------------
// Scenario 4: plan approval + execution (successful tool call).
// ---------------------------------------------------------------------------

static void test_approval_and_successful_execution() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  // Register a mock tool that always succeeds.
  engine->tool_registry().register_tool(
      std::make_unique<MockTool>("finish", "completes the task"));

  // Default plan has 2 tasks (t1 "Implement" + t2 "Verify"). Script the
  // model to (call finish then stop) for BOTH tasks.
  auto push_round = [&loader](const std::string& call_id) {
    existing::LoaderResponse r1;
    r1.finish_reason = "tool_use";
    existing::LoaderToolCall tc;
    tc.id = call_id; tc.name = "finish"; tc.arguments_json = "{}";
    r1.tool_calls.push_back(tc);
    loader.push_scripted_response(r1);
    existing::LoaderResponse r2;
    r2.content = "Task complete.";
    r2.finish_reason = "stop";
    loader.push_scripted_response(r2);
  };
  push_round("tc_t1_a"); push_round("tc_t1_b");
  push_round("tc_t2_a"); push_round("tc_t2_b");

  UserRequest req{"wf4", "Finish the task.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  assert(engine->approve_plan());
  auto r = engine->run();
  // Should be Completed (verifier passed on both tasks, each with a
  // successful tool call as evidence).
  assert(r == AgentEngine::RunResult::Completed);
  assert(engine->state() == WorkflowState::Completed);
  std::cout << "  [ok] approval + successful execution → Completed\n";
}

// ---------------------------------------------------------------------------
// Scenario 5: failed tool calls + bounded retries.
// ---------------------------------------------------------------------------

static void test_failed_tool_calls_and_retries() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  // Mock tool that always fails.
  auto bad_tool = std::make_unique<MockTool>("bad_tool", "always fails");
  bad_tool->set_handler([](const ToolCall& c) {
    ToolResult r;
    r.invocation_id = c.id;
    r.tool_name = "bad_tool";
    r.ok = false;
    r.error = "boom";
    return r;
  });
  engine->tool_registry().register_tool(std::move(bad_tool));

  // Script the model to repeatedly call the bad tool. Each task attempt
  // will end with the tool failing.
  // The agent loop's per-task call limit + max_retries should bound this.
  // We give 4 turns to allow retries.
  for (int i = 0; i < 6; ++i) {
    existing::LoaderResponse r;
    r.finish_reason = "tool_use";
    existing::LoaderToolCall tc;
    tc.id = "tc" + std::to_string(i);
    tc.name = "bad_tool"; tc.arguments_json = "{}";
    r.tool_calls.push_back(tc);
    loader.push_scripted_response(r);
  }

  // Make plan task max_retries small so we don't blow iteration limits.
  UserRequest req{"wf5", "Use the bad tool.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  // Patch the plan task to have max_retries = 1 for a fast test.
  engine->mutable_plan().tasks[0].max_retries = 1;
  engine->approve_plan();
  auto r = engine->run();
  // We expect a non-Completed result. With the new completion semantics
  // (spec §3), a workflow with any Blocked / Failed task must not be
  // reported as Completed. State must be Blocked, Failed, or
  // AwaitingApproval (the latter occurs when recovery triggers a
  // RevisePlan to invalidate approval).
  assert(r != AgentEngine::RunResult::Completed);
  assert(engine->state() == WorkflowState::Blocked ||
         engine->state() == WorkflowState::Failed ||
         engine->state() == WorkflowState::AwaitingApproval);
  // Criteria must NOT be Passed.
  for (const auto& t : engine->current_plan().tasks) {
    for (const auto& a : t.acceptance_criteria) {
      assert(a.status != CriterionStatus::Passed);
    }
  }
  std::cout << "  [ok] failed tool calls → bounded retries → non-completed (state="
            << workflow_state_name(engine->state()) << ")\n";
}

// ---------------------------------------------------------------------------
// Scenario 6: failed verification + recovery.
// ---------------------------------------------------------------------------

static void test_failed_verification_and_recovery() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  // Use a verifier that always fails.
  engine->verifier().set_verify_fn(
      [](const TaskPlan&, const PlanTask&) {
        VerificationResult vr;
        vr.failed_criteria = {"ac1"};
        vr.recommended_action = "retry";
        return vr;
      });

  // Script the model to assert success (stop) without any tool calls —
  // i.e., the model claims success but there's no evidence.
  for (int i = 0; i < 5; ++i) {
    existing::LoaderResponse r;
    r.content = "done";
    r.finish_reason = "stop";
    loader.push_scripted_response(r);
  }

  UserRequest req{"wf6", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  engine->mutable_plan().tasks[0].max_retries = 1;
  engine->approve_plan();
  auto r = engine->run();
  // Should end in non-completed state (Blocked, Failed, or AwaitingApproval
  // if material revision was triggered).
  assert(r != AgentEngine::RunResult::Completed);
  std::cout << "  [ok] failed verification → recovery kicks in (state="
            << workflow_state_name(engine->state()) << ")\n";
}

// ---------------------------------------------------------------------------
// Scenario 7: task dependency blocking.
// ---------------------------------------------------------------------------

static void test_task_dependency_blocking() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  engine->tool_registry().register_tool(
      std::make_unique<MockTool>("finish", "completes"));
  // Script: for the FIRST task, finish tool + stop.
  {
    existing::LoaderResponse r1;
    r1.finish_reason = "tool_use";
    existing::LoaderToolCall tc;
    tc.id = "tc1"; tc.name = "finish"; tc.arguments_json = "{}";
    r1.tool_calls.push_back(tc);
    loader.push_scripted_response(r1);
    existing::LoaderResponse r2;
    r2.content = "done"; r2.finish_reason = "stop";
    loader.push_scripted_response(r2);
  }
  // Patch the plan: t1 -> t2, where t2 has no scriptable model response
  // yet (so t2 will end up either blocked or finish via default stop).
  UserRequest req{"wf7", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  // Make t2 blocked before t1 passes.
  engine->mutable_plan().tasks[1].status = TaskStatus::Blocked;
  engine->approve_plan();
  engine->run();
  // Should end Blocked (no eligible task because t2 is blocked and t1 hasn't
  // passed yet). Since t1 is Pending but t2 is Blocked, the scheduler picks
  // t1 first; if the model completes t1, then t2 is blocked.
  assert(engine->state() == WorkflowState::Blocked ||
         engine->state() == WorkflowState::Completed ||
         engine->state() == WorkflowState::Failed);
  std::cout << "  [ok] task dependency blocking handled (state="
            << workflow_state_name(engine->state()) << ")\n";
}

// ---------------------------------------------------------------------------
// Scenario 8: plan changes during execution.
// ---------------------------------------------------------------------------

static void test_plan_changes_during_execution() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf8", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  engine->approve_plan();
  // Make an edit while in Executing — the coordinator should bump version.
  PlanEdit e;
  e.op = PlanEdit::AddTask;
  PlanTask nt; nt.id = "task_new"; nt.title = "New"; nt.description = "added during exec";
  e.new_task = nt;
  auto outcome = engine->edit_plan(e);
  assert(outcome == EditOutcome::Applied);
  assert(engine->current_plan().find_task("task_new") != nullptr);
  std::cout << "  [ok] plan edit during execution applied\n";
}

// ---------------------------------------------------------------------------
// Scenario 9: cancellation + iteration limits.
// ---------------------------------------------------------------------------

static void test_cancellation() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf9", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  engine->approve_plan();
  engine->cancel("user changed mind");
  assert(engine->state() == WorkflowState::Cancelled);
  // Running again should be a no-op.
  auto r = engine->run();
  assert(r == AgentEngine::RunResult::Cancelled);
  std::cout << "  [ok] cancellation works\n";
}

// ---------------------------------------------------------------------------
// Scenario 10: interrupted workflow + safe resumption.
// ---------------------------------------------------------------------------

static void test_resume() {
  // Single shared repository; both engines write/read it.
  InMemoryPlanRepository shared_repo;

  // Engine 1: submits + approves + checkpoints then "dies".
  existing::ModelLoader loader1;
  {
    auto engine = make_engine_with_loader(loader1, shared_repo);
    UserRequest req{"wf10", "Do a thing.", "2026-10-15T00:00:00Z", {}};
    engine->submit_request(req);
    engine->approve_plan();
    engine->checkpoint("wf10");
  }
  // Engine 1 destroyed; shared_repo retains the snapshot.

  // Engine 2: resumes from the same shared_repo.
  existing::ModelLoader loader2;
  {
    auto engine = make_engine_with_loader(loader2, shared_repo);
    assert(engine->resume("wf10"));
    assert(engine->state() == WorkflowState::Executing);
    // The current plan must match what was checkpointed.
    assert(!engine->current_plan().plan_id.empty());
    // Event log must contain the prior checkpoint event.
    bool saw_checkpoint = false;
    for (const auto& e : engine->event_log().snapshot()) {
      if (e.message.find("checkpointed wf10") != std::string::npos) {
        saw_checkpoint = true; break;
      }
    }
    assert(saw_checkpoint);
  }
  std::cout << "  [ok] resume from checkpoint preserves state + events\n";
}

// ---------------------------------------------------------------------------
// Scenario 11: markdown consistency with structured state.
// ---------------------------------------------------------------------------

static void test_markdown_consistency() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  UserRequest req{"wf11", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  auto tp = engine->render_task_plan_md();
  auto fd = engine->render_findings_md();
  auto pg = engine->render_progress_md();
  // task_plan.md must reference the plan id.
  assert(tp.find(engine->current_plan().plan_id) != std::string::npos);
  // findings.md must always have the title.
  assert(fd.find("# Findings") != std::string::npos);
  // progress.md must reflect current state.
  assert(pg.find(workflow_state_name(engine->state())) != std::string::npos);
  std::cout << "  [ok] markdown consistent with structured state\n";
}

// ---------------------------------------------------------------------------
// Scenario 12: invalid tool arguments + unauthorized operations.
// ---------------------------------------------------------------------------

static void test_invalid_and_unauthorized_tool_args() {
  existing::ModelLoader loader;
  InMemoryPlanRepository repo;
  auto engine = make_engine_with_loader(loader, repo);
  // Register a LocalFileTool.
  engine->tool_registry().register_tool(
      std::make_unique<LocalFileTool>("/demo_workspace"));

  // Script: model requests an unauthorized tool + then a tool with bad args
  // + then a normal tool call.
  {
    existing::LoaderResponse r1;
    r1.finish_reason = "tool_use";
    existing::LoaderToolCall tc;
    tc.id = "tc1"; tc.name = "hacker_tool"; tc.arguments_json = "{}";
    r1.tool_calls.push_back(tc);
    loader.push_scripted_response(r1);

    existing::LoaderResponse r2;
    r2.finish_reason = "tool_use";
    existing::LoaderToolCall tc2;
    tc2.id = "tc2"; tc2.name = "local_file";
    // Malformed (missing path).
    tc2.arguments_json = "{\"op\":\"read\"}";
    r2.tool_calls.push_back(tc2);
    loader.push_scripted_response(r2);

    existing::LoaderResponse r3;
    r3.finish_reason = "stop";
    r3.content = "I'll stop now.";
    loader.push_scripted_response(r3);
  }

  UserRequest req{"wf12", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  engine->submit_request(req);
  engine->mutable_plan().tasks[0].max_retries = 0;
  engine->approve_plan();
  engine->run();
  // Verify the unauthorized + invalid calls were recorded as failures.
  const auto& t = engine->current_plan().tasks[0];
  assert(t.executed_calls.size() >= 2);
  int failures = 0;
  for (const auto& ec : t.executed_calls) {
    if (!ec.ok) ++failures;
  }
  assert(failures >= 2);
  std::cout << "  [ok] unauthorized + invalid tool args recorded as failures\n";
}

int main() {
  std::cout << "[phase7] end-to-end integration\n";
  test_straightforward_request();
  test_clarification_request();
  test_plan_reject_and_revise();
  test_approval_and_successful_execution();
  test_failed_tool_calls_and_retries();
  test_failed_verification_and_recovery();
  test_task_dependency_blocking();
  test_plan_changes_during_execution();
  test_cancellation();
  test_resume();
  test_markdown_consistency();
  test_invalid_and_unauthorized_tool_args();
  std::cout << "[phase7] all tests passed\n";
  return 0;
}
