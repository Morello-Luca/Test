// test_phase6.cpp — Phase 6: progress tracker + repository + resumability.

#include "core/artifacts/ProgressTracker.h"
#include "core/storage/InMemoryPlanRepository.h"
#include "core/WorkflowState.h"
#include "core/models/DomainModels.h"
#include "core/models/ToolExecutionTypes.h"
#include "core/artifacts/EventLog.h"

#include <cassert>
#include <iostream>
#include <memory>

using namespace agent_engine;

// ---- ProgressTracker -----------------------------------------------------

static void test_progress_next_action_states() {
  TaskPlan p; p.version = 3;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Pending;
  p.tasks = {t1};

  assert(ProgressTracker::next_action(WorkflowState::AwaitingApproval, p)
         .find("approval") != std::string::npos);
  assert(ProgressTracker::next_action(WorkflowState::Executing, p)
         .find("t1") != std::string::npos);
  assert(ProgressTracker::next_action(WorkflowState::Completed, p)
         .find("complete") != std::string::npos);
  assert(ProgressTracker::next_action(WorkflowState::Blocked, p)
         .find("blocked") != std::string::npos);
  std::cout << "  [ok] next_action for various states\n";
}

static void test_progress_next_action_blocked_when_no_eligible() {
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Passed;
  PlanTask t2; t2.id = "t2"; t2.status = TaskStatus::Pending;
  t2.dependencies = {"t_missing"};  // missing dep, will never be eligible
  p.tasks = {t1, t2};
  auto s = ProgressTracker::next_action(WorkflowState::Executing, p);
  assert(s.find("blocked") != std::string::npos ||
         s.find("No eligible") != std::string::npos);
  std::cout << "  [ok] next_action reports no eligible task when deps missing\n";
}

static void test_is_complete_with_passed_and_terminal() {
  // Spec §3: a workflow is complete ONLY when every task is Passed AND
  // every required acceptance criterion is Passed. A skipped/failed task
  // does NOT count as completion.
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Passed;
  // Make sure t1's criteria are also Passed (otherwise is_complete should
  // return false even with status=Passed).
  t1.acceptance_criteria.push_back({"ac1", "must pass", true,
                                     CriterionStatus::Passed});
  p.tasks = {t1};
  assert(ProgressTracker::is_complete(p));
  std::cout << "  [ok] is_complete true only when ALL tasks Passed (Skipped no longer counts)\n";
}

static void test_is_complete_false_with_pending() {
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Passed;
  t1.acceptance_criteria.push_back({"ac1", "must pass", true,
                                     CriterionStatus::Passed});
  PlanTask t2; t2.id = "t2"; t2.status = TaskStatus::Pending;
  p.tasks = {t1, t2};
  assert(!ProgressTracker::is_complete(p));
  assert(!ProgressTracker::is_failed(p));
  assert(!ProgressTracker::is_blocked(p));
  std::cout << "  [ok] is_complete false with non-terminal task\n";
}

static void test_is_complete_false_with_no_passed() {
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Failed;
  PlanTask t2; t2.id = "t2"; t2.status = TaskStatus::Skipped;
  p.tasks = {t1, t2};
  assert(!ProgressTracker::is_complete(p));
  assert(ProgressTracker::is_failed(p));
  assert(!ProgressTracker::is_blocked(p));
  std::cout << "  [ok] is_complete false when no task Passed; is_failed true when any Failed\n";
}

static void test_is_complete_false_with_passed_and_blocked() {
  // Spec §3: a Blocked task must prevent successful completion.
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Passed;
  t1.acceptance_criteria.push_back({"ac1", "must pass", true,
                                     CriterionStatus::Passed});
  PlanTask t2; t2.id = "t2"; t2.status = TaskStatus::Blocked;
  p.tasks = {t1, t2};
  assert(!ProgressTracker::is_complete(p));
  assert(ProgressTracker::is_blocked(p));
  std::cout << "  [ok] is_complete false when any task Blocked (new regression check)\n";
}

static void test_is_complete_false_when_criterion_not_passed() {
  // Spec §3: even if task status is Passed, if a required criterion is
  // not yet Passed (e.g., still Defined/Pending), workflow is not complete.
  TaskPlan p;
  PlanTask t1; t1.id = "t1"; t1.status = TaskStatus::Passed;
  t1.acceptance_criteria.push_back({"ac1", "must pass", true,
                                     CriterionStatus::Defined});
  p.tasks = {t1};
  assert(!ProgressTracker::is_complete(p));
  std::cout << "  [ok] is_complete false when required criterion not Passed (new regression check)\n";
}

// ---- InMemoryPlanRepository ---------------------------------------------

static WorkflowSnapshot make_snapshot(const std::string& id, int plan_v,
                                        WorkflowState state) {
  WorkflowSnapshot s;
  s.workflow_id = id;
  s.original_request = UserRequest{"r1", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  s.plan.plan_id = "p_" + id;
  s.plan.request_id = "r1";
  s.plan.version = plan_v;
  s.plan.approved = false;
  PlanTask t; t.id = "t1"; t.title = "Do";
  s.plan.tasks = {t};
  s.state = state;
  return s;
}

static void test_repository_save_load_roundtrip() {
  InMemoryPlanRepository repo;
  auto snap = make_snapshot("wf-1", 3, WorkflowState::Executing);
  repo.save(snap);
  auto loaded = repo.load("wf-1");
  assert(loaded != nullptr);
  assert(loaded->workflow_id == "wf-1");
  assert(loaded->plan.version == 3);
  assert(loaded->state == WorkflowState::Executing);
  std::cout << "  [ok] save → load roundtrip preserves state\n";
}

static void test_repository_save_overwrites() {
  InMemoryPlanRepository repo;
  repo.save(make_snapshot("wf-2", 1, WorkflowState::Planning));
  repo.save(make_snapshot("wf-2", 2, WorkflowState::AwaitingApproval));
  assert(repo.size() == 1);
  auto loaded = repo.load("wf-2");
  assert(loaded->plan.version == 2);
  assert(loaded->state == WorkflowState::AwaitingApproval);
  std::cout << "  [ok] save overwrites previous snapshot\n";
}

static void test_repository_load_missing_returns_null() {
  InMemoryPlanRepository repo;
  assert(repo.load("nope") == nullptr);
  std::cout << "  [ok] load of missing id returns nullptr\n";
}

static void test_repository_list_and_remove() {
  InMemoryPlanRepository repo;
  repo.save(make_snapshot("wf-a", 1, WorkflowState::Draft));
  repo.save(make_snapshot("wf-b", 1, WorkflowState::Draft));
  auto ids = repo.list_workflow_ids();
  assert(ids.size() == 2);
  repo.remove("wf-a");
  assert(repo.size() == 1);
  assert(repo.load("wf-a") == nullptr);
  std::cout << "  [ok] list_workflow_ids + remove work\n";
}

// ---- Resumability: roundtrip preserves enough to resume -----------------

static void test_resumability_preserves_plan_and_state() {
  InMemoryPlanRepository repo;
  WorkflowSnapshot snap = make_snapshot("wf-resume", 5,
                                          WorkflowState::Recovering);
  PlanTask t2; t2.id = "t2"; t2.title = "Verify";
  t2.status = TaskStatus::AwaitingVerification;
  t2.dependencies = {"t1"};
  t2.attempts = 2;
  t2.max_retries = 3;
  t2.has_unverified_claim = true;
  t2.executed_calls.push_back(PlanTask::ExecutedCall{
      "call_1", "local_file", "{}", "{\"ok\":true}", true, ""});
  snap.plan.tasks.push_back(t2);

  snap.events.push_back(WorkflowEvent{
      WorkflowEventKind::TaskSelected, "2026-10-15T00:00:00Z",
      "Executing", "selected t2", {}});
  snap.last_action_summary = "recover t2 (attempt 2/3)";

  repo.save(snap);
  auto loaded = repo.load("wf-resume");
  assert(loaded != nullptr);
  // Spec §10: persist task statuses + deps + retry counts + execution history.
  assert(loaded->plan.tasks.size() == 2);
  assert(loaded->plan.tasks[1].status == TaskStatus::AwaitingVerification);
  assert(loaded->plan.tasks[1].attempts == 2);
  assert(loaded->plan.tasks[1].max_retries == 3);
  assert(loaded->plan.tasks[1].has_unverified_claim);
  assert(loaded->plan.tasks[1].executed_calls.size() == 1);
  assert(loaded->state == WorkflowState::Recovering);
  assert(!loaded->events.empty());
  assert(loaded->last_action_summary == "recover t2 (attempt 2/3)");
  std::cout << "  [ok] resumability: snapshot preserves everything needed to resume\n";
}

// ---- Spec §10: "Do not automatically repeat a non-idempotent action
//                if its previous outcome is unknown."
// We don't have a non-idempotent action impl yet, but we ensure the
// snapshot records the previous outcome so the resume path can see it.

static void test_resume_does_not_repeat_unknown_outcome_action() {
  InMemoryPlanRepository repo;
  // Simulate a task that made a tool call but the result was never recorded
  // (i.e., workflow was interrupted mid-dispatch).
  WorkflowSnapshot snap = make_snapshot("wf-interrupt", 1,
                                          WorkflowState::Paused);
  PlanTask& t = snap.plan.tasks[0];
  t.status = TaskStatus::InProgress;
  t.attempts = 1;
  // An executed call without ok=false, just empty (i.e., outcome unknown).
  PlanTask::ExecutedCall ec;
  ec.tool_call_id = "call_x";
  ec.tool_name = "local_file";
  ec.arguments_json = "{\"op\":\"write\",\"path\":\"x\"}";
  ec.result_json = "";  // empty => outcome unknown
  ec.ok = false;
  ec.error = "interrupted before tool result";
  t.executed_calls.push_back(ec);
  repo.save(snap);

  auto loaded = repo.load("wf-interrupt");
  assert(loaded != nullptr);
  // On resume: the recovery manager should see the failed/interrupted call
  // and treat it as missing evidence (rather than blindly re-running the
  // non-idempotent write). We assert the executed_call is preserved so a
  // real recovery manager can examine it.
  assert(loaded->plan.tasks[0].executed_calls.size() == 1);
  assert(loaded->plan.tasks[0].executed_calls[0].error.find("interrupted")
         != std::string::npos);
  std::cout << "  [ok] resumability preserves unknown-outcome call for examination\n";
}

int main() {
  std::cout << "[phase6] progress + resumability\n";
  test_progress_next_action_states();
  test_progress_next_action_blocked_when_no_eligible();
  test_is_complete_with_passed_and_terminal();
  test_is_complete_false_with_pending();
  test_is_complete_false_with_no_passed();
  test_is_complete_false_with_passed_and_blocked();
  test_is_complete_false_when_criterion_not_passed();
  test_repository_save_load_roundtrip();
  test_repository_save_overwrites();
  test_repository_load_missing_returns_null();
  test_repository_list_and_remove();
  test_resumability_preserves_plan_and_state();
  test_resume_does_not_repeat_unknown_outcome_action();
  std::cout << "[phase6] all tests passed\n";
  return 0;
}
