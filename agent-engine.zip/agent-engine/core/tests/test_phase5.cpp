// test_phase5.cpp — Phase 5: verification + recovery.

#include "core/execution/ResultVerifier.h"
#include "core/execution/RecoveryManager.h"
#include "core/artifacts/EventLog.h"
#include "core/models/DomainModels.h"

#include <cassert>
#include <iostream>

using namespace agent_engine;

// ---- Verifier passes on evidence ----------------------------------------

static void test_verifier_passes_with_evidence() {
  EventLog log;
  ResultVerifier v(log);
  PlanTask t;
  t.id = "t1";
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  PlanTask::ExecutedCall ec;
  ec.ok = true;
  ec.tool_name = "local_file";
  ec.result_json = "{\"ok\":true}";
  t.executed_calls = {ec};
  t.has_unverified_claim = true;  // model asserted success
  auto r = v.verify({}, t);
  assert(r.overall_passed);
  assert(r.passed_criteria.size() == 1);
  assert(r.recommended_action == "pass" || r.recommended_action.empty());
  std::cout << "  [ok] verifier passes with positive evidence\n";
}

// ---- Verifier flags missing evidence ------------------------------------

static void test_verifier_flags_missing_evidence() {
  EventLog log;
  ResultVerifier v(log);
  PlanTask t;
  t.id = "t2";
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  t.has_unverified_claim = true;
  t.executed_calls = {};  // no evidence
  auto r = v.verify({}, t);
  assert(!r.overall_passed);
  assert(!r.missing_evidence.empty());
  assert(r.recommended_action == "retry");
  std::cout << "  [ok] verifier flags missing evidence\n";
}

// ---- Verifier fails on failed tool calls --------------------------------

static void test_verifier_fails_on_tool_error() {
  EventLog log;
  ResultVerifier v(log);
  PlanTask t;
  t.id = "t3";
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  PlanTask::ExecutedCall ec;
  ec.ok = false;
  ec.error = "boom";
  t.executed_calls = {ec};
  auto r = v.verify({}, t);
  assert(!r.overall_passed);
  assert(!r.failed_criteria.empty());
  assert(r.recommended_action == "retry");
  std::cout << "  [ok] verifier fails on failed tool calls\n";
}

// ---- Recovery: retry when attempts remain -------------------------------

static void test_recovery_retries_within_bounds() {
  EventLog log;
  ResultVerifier v(log);
  RecoveryManager rm(log, v);
  TaskPlan plan;
  PlanTask t;
  t.id = "t1";
  t.max_retries = 2;
  t.attempts = 1;
  t.status = TaskStatus::AwaitingVerification;
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  plan.tasks = {t};

  VerificationResult vr;
  vr.task_id = "t1";
  vr.failed_criteria = {"ac1"};
  vr.recommended_action = "retry";

  auto d = rm.diagnose(plan, plan.tasks[0], vr);
  assert(d.action == RecoveryAction::RetryTask);
  rm.apply(plan, plan.tasks[0], d);
  assert(plan.find_task("t1")->status == TaskStatus::Pending);
  // executed_calls should NOT have been reset.
  std::cout << "  [ok] recovery retries when attempts remain\n";
}

// ---- Recovery: blocks when attempts exhausted ---------------------------

static void test_recovery_blocks_when_exhausted() {
  EventLog log;
  ResultVerifier v(log);
  RecoveryManager rm(log, v);
  TaskPlan plan;
  PlanTask t;
  t.id = "t1";
  t.max_retries = 2;
  t.attempts = 3;  // exhausted
  t.status = TaskStatus::AwaitingVerification;
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  plan.tasks = {t};

  VerificationResult vr;
  vr.task_id = "t1";
  vr.failed_criteria = {"ac1"};
  vr.recommended_action = "retry";

  auto d = rm.diagnose(plan, plan.tasks[0], vr);
  // Hard failure + exhausted retries → RevisePlan per §4.3.
  assert(d.action == RecoveryAction::RevisePlan);
  rm.apply(plan, plan.tasks[0], d);
  // Plan version bumped, not approved, task blocked.
  assert(plan.version >= 1);
  assert(!plan.approved);
  assert(plan.find_task("t1")->status == TaskStatus::Blocked);
  std::cout << "  [ok] recovery escalates to plan revision when exhausted\n";
}

// ---- Recovery: missing-evidence path ------------------------------------

static void test_recovery_blocks_on_missing_evidence_exhausted() {
  EventLog log;
  ResultVerifier v(log);
  RecoveryManager rm(log, v);
  TaskPlan plan;
  PlanTask t;
  t.id = "t2";
  t.max_retries = 2;
  t.attempts = 3;
  t.status = TaskStatus::AwaitingVerification;
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  plan.tasks = {t};

  VerificationResult vr;
  vr.task_id = "t2";
  vr.missing_evidence = {"ac1"};
  vr.recommended_action = "retry";

  auto d = rm.diagnose(plan, plan.tasks[0], vr);
  assert(d.action == RecoveryAction::BlockTask);
  rm.apply(plan, plan.tasks[0], d);
  assert(plan.find_task("t2")->status == TaskStatus::Blocked);
  std::cout << "  [ok] recovery blocks when missing-evidence retries exhausted\n";
}

// ---- Recovery: no-op when verification passed ---------------------------

static void test_recovery_noop_when_passed() {
  EventLog log;
  ResultVerifier v(log);
  RecoveryManager rm(log, v);
  TaskPlan plan;
  PlanTask t;
  t.id = "t3";
  t.max_retries = 2;
  t.attempts = 1;
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  plan.tasks = {t};

  VerificationResult vr;
  vr.task_id = "t3";
  vr.overall_passed = true;
  vr.passed_criteria = {"ac1"};
  vr.recommended_action = "pass";

  auto d = rm.diagnose(plan, plan.tasks[0], vr);
  assert(d.action == RecoveryAction::SkipTask);
  rm.apply(plan, plan.tasks[0], d);
  // Status unchanged.
  assert(plan.find_task("t3")->status == TaskStatus::Pending);
  std::cout << "  [ok] recovery no-ops when verification passed\n";
}

// ---- End-to-end: verify → recover → retry → pass -----------------------

static void test_end_to_end_verify_recover_retry_pass() {
  EventLog log;
  ResultVerifier v(log);
  RecoveryManager rm(log, v);
  TaskPlan plan;
  PlanTask t;
  t.id = "t4";
  t.max_retries = 2;
  t.attempts = 0;
  t.acceptance_criteria = {{"ac1", "matches intent", true}};
  plan.tasks = {t};

  // Round 1: model asserted success without evidence → missing_evidence → retry.
  t.has_unverified_claim = true;
  t.executed_calls = {};
  auto vr1 = v.verify(plan, t);
  assert(!vr1.missing_evidence.empty());
  auto d1 = rm.diagnose(plan, t, vr1);
  assert(d1.action == RecoveryAction::RetryTask);
  rm.apply(plan, t, d1);
  t.attempts += 1;

  // Round 2: provide evidence → verify passes.
  PlanTask::ExecutedCall ec;
  ec.ok = true;
  ec.tool_name = "finish";
  t.executed_calls = {ec};
  auto vr2 = v.verify(plan, t);
  assert(vr2.overall_passed);
  auto d2 = rm.diagnose(plan, t, vr2);
  assert(d2.action == RecoveryAction::SkipTask);

  std::cout << "  [ok] end-to-end: verify → recover → retry → pass\n";
}

int main() {
  std::cout << "[phase5] verification & recovery\n";
  test_verifier_passes_with_evidence();
  test_verifier_flags_missing_evidence();
  test_verifier_fails_on_tool_error();
  test_recovery_retries_within_bounds();
  test_recovery_blocks_when_exhausted();
  test_recovery_blocks_on_missing_evidence_exhausted();
  test_recovery_noop_when_passed();
  test_end_to_end_verify_recover_retry_pass();
  std::cout << "[phase5] all tests passed\n";
  return 0;
}
