// test_phase2.cpp — Phase 2: state machine, event log, domain models.

#include "core/WorkflowState.h"
#include "core/models/DomainModels.h"
#include "core/models/ToolExecutionTypes.h"
#include "core/artifacts/EventLog.h"

#include <cassert>
#include <iostream>
#include <thread>
#include <vector>

using namespace agent_engine;

// ---- WorkflowState -------------------------------------------------------

static void test_state_transitions_legal() {
  assert(is_valid_transition(WorkflowState::Draft, WorkflowState::Planning));
  assert(is_valid_transition(WorkflowState::Planning,
                              WorkflowState::AwaitingApproval));
  assert(is_valid_transition(WorkflowState::AwaitingApproval,
                              WorkflowState::Executing));
  assert(is_valid_transition(WorkflowState::Executing,
                              WorkflowState::Verifying));
  assert(is_valid_transition(WorkflowState::Executing,
                              WorkflowState::Recovering));
  assert(is_valid_transition(WorkflowState::Recovering,
                              WorkflowState::AwaitingApproval));
  std::cout << "  [ok] legal transitions accepted\n";
}

static void test_state_transitions_illegal() {
  // Draft cannot jump straight to Executing.
  assert(!is_valid_transition(WorkflowState::Draft,
                                WorkflowState::Executing));
  // Terminal states have no outgoing transitions.
  for (auto term : {WorkflowState::Completed, WorkflowState::Cancelled,
                     WorkflowState::Failed}) {
    for (int i = 0; i <= static_cast<int>(WorkflowState::Failed); ++i) {
      assert(!is_valid_transition(term, static_cast<WorkflowState>(i)));
    }
  }
  // Self-transition is not a valid transition (must use explicit no-op).
  assert(!is_valid_transition(WorkflowState::Planning,
                                WorkflowState::Planning));
  std::cout << "  [ok] illegal transitions rejected\n";
}

// ---- Domain models -------------------------------------------------------

static void test_plan_find_task() {
  TaskPlan p;
  p.request_id = "r1";
  p.plan_id = "p1";
  PlanTask t1; t1.id = "t1"; t1.title = "First";
  PlanTask t2; t2.id = "t2"; t2.title = "Second"; t2.dependencies = {"t1"};
  p.tasks = {t1, t2};
  assert(p.find_task("t2") != nullptr);
  assert(p.find_task("missing") == nullptr);
  assert(p.find_task("t1")->title == "First");
  std::cout << "  [ok] TaskPlan::find_task lookup works\n";
}

static void test_material_change_detection() {
  TaskPlan p; p.version = 1;
  assert(p.is_material_change_since(0));
  assert(!p.is_material_change_since(1));
  std::cout << "  [ok] material change detection works\n";
}

// ---- Event log -----------------------------------------------------------

static void test_event_log_append_and_subscribe() {
  EventLog log;
  int got = 0;
  int sub = log.subscribe([&](const WorkflowEvent&){ ++got; });

  log.log(WorkflowEventKind::PlanCreated, "Planning",
          "plan v1 created", {{"plan_id", "p1"}});
  log.log(WorkflowEventKind::TaskSelected, "Executing",
          "selected t1");

  auto snap = log.snapshot();
  assert(snap.size() == 2);
  assert(snap[0].kind == WorkflowEventKind::PlanCreated);
  assert(snap[0].details.at("plan_id") == "p1");
  assert(snap[0].workflow_state == "Planning");
  assert(!snap[0].timestamp_iso.empty());
  assert(got == 2);

  log.unsubscribe(sub);
  log.log(WorkflowEventKind::Note, "Planning", "no subscriber");
  assert(got == 2);  // did not increment after unsubscribe

  std::cout << "  [ok] EventLog append, snapshot, subscribe work\n";
}

static void test_event_log_thread_safety() {
  EventLog log;
  std::vector<std::thread> threads;
  int N = 8, per = 200;
  for (int i = 0; i < N; ++i) {
    threads.emplace_back([&log, i, per]() {
      for (int j = 0; j < per; ++j) {
        log.log(WorkflowEventKind::Note, "Executing",
                "thread " + std::to_string(i));
      }
    });
  }
  for (auto& th : threads) th.join();
  auto snap = log.snapshot();
  assert(static_cast<int>(snap.size()) == N * per);
  std::cout << "  [ok] EventLog thread-safety under concurrent appends\n";
}

int main() {
  std::cout << "[phase2] domain & workflow foundation\n";
  test_state_transitions_legal();
  test_state_transitions_illegal();
  test_plan_find_task();
  test_material_change_detection();
  test_event_log_append_and_subscribe();
  test_event_log_thread_safety();
  std::cout << "[phase2] all tests passed\n";
  return 0;
}
