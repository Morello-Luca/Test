// test_phase3.cpp — Phase 3: planning + markdown rendering.

#include "core/planning/PlanCoordinator.h"
#include "core/planning/RequestAnalyzer.h"
#include "core/planning/ContextAnalyzer.h"
#include "core/planning/TaskDecomposer.h"
#include "core/planning/PlanValidator.h"
#include "core/artifacts/MarkdownRenderer.h"
#include "core/artifacts/EventLog.h"

#include <cassert>
#include <iostream>
#include <memory>
#include <string>

using namespace agent_engine;

static std::unique_ptr<PlanCoordinator> make_coordinator(EventLog& log) {
  return std::make_unique<PlanCoordinator>(
    log,
    std::make_unique<RequestAnalyzer>(),
    std::make_unique<ContextAnalyzer>(),
    std::make_unique<TaskDecomposer>(),
    std::make_unique<PlanValidator>());
}

// ---- Straightforward request (no ambiguity) ------------------------------

static void test_straightforward_request() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r1", "Add a README file to the repo.", "2026-10-15T00:00:00Z", {}};
  auto analysis = coord->analyze_request(req);
  assert(!analysis.needs_clarification());
  auto plan = coord->produce_draft_plan(req);
  assert(plan.request_id == "r1");
  assert(!plan.tasks.empty());
  auto v = coord->validate(plan);
  assert(v.ok);
  std::cout << "  [ok] straightforward request → valid draft plan\n";
}

// ---- Ambiguous request → clarification -----------------------------------

static void test_ambiguous_request_triggers_clarification() {
  EventLog log;
  auto coord = make_coordinator(log);
  // User asks a question — ambiguity signal in our heuristic.
  UserRequest req{"r2", "What about the API? Should it be REST or GraphQL?",
                  "2026-10-15T00:00:00Z", {}};
  auto analysis = coord->analyze_request(req);
  assert(analysis.needs_clarification());
  assert(!analysis.clarifying_questions.empty());
  // EventLog should have a ClarificationRequested entry.
  auto snap = log.snapshot();
  bool saw_event = false;
  for (const auto& e : snap) {
    if (e.kind == WorkflowEventKind::ClarificationRequested) { saw_event = true; break; }
  }
  assert(saw_event);
  std::cout << "  [ok] ambiguous request → clarification event\n";
}

// ---- Plan approval + rejection -------------------------------------------

static void test_plan_approval_and_rejection() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r3", "Write a unit test.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  assert(!plan.approved);
  coord->approve(plan);
  assert(plan.approved);
  assert(plan.version >= 1);

  // Rejection on a fresh plan.
  auto plan2 = coord->produce_draft_plan(req);
  coord->reject(plan2, "too risky");
  // Event recorded.
  auto snap = log.snapshot();
  bool saw_reject = false;
  for (const auto& e : snap) {
    if (e.kind == WorkflowEventKind::PlanRejected) { saw_reject = true; break; }
  }
  assert(saw_reject);
  std::cout << "  [ok] plan approve/reject works\n";
}

// ---- Plan edit: add task -------------------------------------------------

static void test_add_task_edit() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r4", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  size_t before = plan.tasks.size();
  PlanEdit edit;
  edit.op = PlanEdit::AddTask;
  PlanTask nt;
  nt.id = "task_extra";
  nt.title = "Extra";
  nt.description = "extra work";
  edit.new_task = nt;
  auto r = coord->apply_edit(plan, edit);
  assert(r == EditOutcome::Applied);
  assert(plan.tasks.size() == before + 1);
  assert(plan.find_task("task_extra") != nullptr);
  // Version should have bumped.
  assert(plan.version >= 1);
  std::cout << "  [ok] AddTask edit works\n";
}

// ---- Plan edit: invalid dependency rejected ------------------------------

static void test_invalid_dependency_rejected() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r5", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  PlanEdit edit;
  edit.op = PlanEdit::AddTask;
  PlanTask nt;
  nt.id = "task_bad";
  nt.title = "Bad";
  nt.dependencies = {"nonexistent_id"};
  edit.new_task = nt;
  auto r = coord->apply_edit(plan, edit);
  assert(r == EditOutcome::RejectedInvalidDependency);
  std::cout << "  [ok] invalid dependency rejected\n";
}

// ---- Plan edit: remove task cleans up deps ------------------------------

static void test_remove_task_cleans_deps() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r6", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  // Default plan has task_02 -> task_01 dependency.
  PlanEdit edit;
  edit.op = PlanEdit::RemoveTask;
  edit.task_id = "task_01";
  assert(coord->apply_edit(plan, edit) == EditOutcome::Applied);
  // Verify no remaining task references task_01.
  for (const auto& t : plan.tasks) {
    for (const auto& d : t.dependencies) {
      assert(d != "task_01");
    }
  }
  std::cout << "  [ok] RemoveTask cleans dependencies\n";
}

// ---- Plan revision (with note) -------------------------------------------

static void test_request_revision() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r7", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  auto v0 = plan.version;
  auto revised = coord->request_revision(plan, req, "prefer shorter steps");
  assert(revised.version == v0 + 1);
  assert(revised.plan_id == plan.plan_id);
  // Note: the user note is folded into the *request's* extra_context, not the
  // plan's, so we don't assert on it here — the version bump already proves
  // a revision occurred.
  std::cout << "  [ok] request_revision bumps version\n";
}

// ---- Validator catches cycles -------------------------------------------

static void test_validator_catches_cycles() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r8", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  // Hand-craft a cycle: task_01 depends on task_02.
  PlanEdit e;
  e.op = PlanEdit::AddDependency;
  e.task_id = "task_01";
  e.dep_id = "task_02";
  auto r = coord->apply_edit(plan, e);
  // Either rejected outright (validator says cycle) or applied but then
  // validation fails. Our impl re-validates on AddDependency and rolls back.
  assert(r == EditOutcome::RejectedInvalidDependency);
  std::cout << "  [ok] cycle-creating dependency rejected\n";
}

// ---- Markdown consistency with structured state -------------------------

static void test_markdown_reflects_state() {
  EventLog log;
  auto coord = make_coordinator(log);
  UserRequest req{"r9", "Do a thing.", "2026-10-15T00:00:00Z", {}};
  auto plan = coord->produce_draft_plan(req);
  MarkdownRenderer r(log);
  auto tp = r.render_task_plan(plan);
  auto fd = r.render_findings(plan);
  auto pg = r.render_progress(plan, "Run task_01");
  // Each must reference plan id + at least one task id.
  assert(tp.find(plan.plan_id) != std::string::npos);
  assert(tp.find("task_01") != std::string::npos);
  assert(fd.find("Assumptions") != std::string::npos ||
         fd.find("No findings") != std::string::npos ||
         fd.find("Risks") != std::string::npos);
  assert(pg.find("Progress") != std::string::npos);
  assert(pg.find("Run task_01") != std::string::npos);
  std::cout << "  [ok] markdown reflects structured state\n";
}

int main() {
  std::cout << "[phase3] interactive planning + markdown\n";
  test_straightforward_request();
  test_ambiguous_request_triggers_clarification();
  test_plan_approval_and_rejection();
  test_add_task_edit();
  test_invalid_dependency_rejected();
  test_remove_task_cleans_deps();
  test_request_revision();
  test_validator_catches_cycles();
  test_markdown_reflects_state();
  std::cout << "[phase3] all tests passed\n";
  return 0;
}
