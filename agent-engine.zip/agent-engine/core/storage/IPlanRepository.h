// IPlanRepository.h
//
// Spec §10: abstraction for saving / loading structured plans. Begins with
// in-memory; local-storage / DB integration is out of initial scope.
//
// Persisted snapshot covers: original request, current plan + revision,
// task statuses + deps, workflow state, context + findings, execution
// history, tool call + result records, retry counts + limits, pending
// approvals, last completed + next eligible actions.

#ifndef AGENT_ENGINE_CORE_STORAGE_I_PLAN_REPOSITORY_H
#define AGENT_ENGINE_CORE_STORAGE_I_PLAN_REPOSITORY_H

#include "core/WorkflowState.h"
#include "core/models/DomainModels.h"
#include "core/models/ToolExecutionTypes.h"

#include <memory>
#include <string>
#include <vector>

namespace agent_engine {

/// Full snapshot of a workflow at a point in time. Used by
/// InMemoryPlanRepository to support resumability.
struct WorkflowSnapshot {
  std::string workflow_id;        // logical workflow identifier
  UserRequest original_request;
  TaskPlan plan;                   // current plan + revision
  WorkflowState state = WorkflowState::Draft;
  std::vector<WorkflowEvent> events;  // full event log (replay on resume)
  std::string last_action_summary;     // human-readable hint
};

class IPlanRepository {
 public:
  virtual ~IPlanRepository() = default;

  /// Save a snapshot, replacing any existing one with the same workflow_id.
  virtual void save(const WorkflowSnapshot& snap) = 0;

  /// Load a snapshot by workflow_id; returns nullptr if not found.
  virtual std::unique_ptr<WorkflowSnapshot> load(
      const std::string& workflow_id) const = 0;

  /// List all known workflow ids.
  virtual std::vector<std::string> list_workflow_ids() const = 0;

  /// Remove a snapshot (no-op if missing).
  virtual void remove(const std::string& workflow_id) = 0;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_STORAGE_I_PLAN_REPOSITORY_H
