// InMemoryPlanRepository.cpp

#include "InMemoryPlanRepository.h"

namespace agent_engine {

void InMemoryPlanRepository::save(const WorkflowSnapshot& snap) {
  std::lock_guard<std::mutex> lk(mtx_);
  store_[snap.workflow_id] = snap;
}

std::unique_ptr<WorkflowSnapshot> InMemoryPlanRepository::load(
    const std::string& workflow_id) const {
  std::lock_guard<std::mutex> lk(mtx_);
  auto it = store_.find(workflow_id);
  if (it == store_.end()) return nullptr;
  auto out = std::make_unique<WorkflowSnapshot>(it->second);  // copy
  return out;
}

std::vector<std::string> InMemoryPlanRepository::list_workflow_ids()
    const {
  std::lock_guard<std::mutex> lk(mtx_);
  std::vector<std::string> out;
  out.reserve(store_.size());
  for (const auto& [id, _] : store_) out.push_back(id);
  return out;
}

void InMemoryPlanRepository::remove(const std::string& workflow_id) {
  std::lock_guard<std::mutex> lk(mtx_);
  store_.erase(workflow_id);
}

size_t InMemoryPlanRepository::size() const {
  std::lock_guard<std::mutex> lk(mtx_);
  return store_.size();
}

}  // namespace agent_engine
