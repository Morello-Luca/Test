// InMemoryPlanRepository.h
//
// In-memory implementation of IPlanRepository. Per spec §10, this is the
// initial implementation; real local-storage / DB integration is deferred.

#ifndef AGENT_ENGINE_CORE_STORAGE_IN_MEMORY_PLAN_REPOSITORY_H
#define AGENT_ENGINE_CORE_STORAGE_IN_MEMORY_PLAN_REPOSITORY_H

#include "IPlanRepository.h"

#include <mutex>
#include <unordered_map>

namespace agent_engine {

class InMemoryPlanRepository : public IPlanRepository {
 public:
  void save(const WorkflowSnapshot& snap) override;
  std::unique_ptr<WorkflowSnapshot> load(
      const std::string& workflow_id) const override;
  std::vector<std::string> list_workflow_ids() const override;
  void remove(const std::string& workflow_id) override;

  // Test-only helpers.
  size_t size() const;

 private:
  mutable std::mutex mtx_;
  std::unordered_map<std::string, WorkflowSnapshot> store_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_STORAGE_IN_MEMORY_PLAN_REPOSITORY_H
