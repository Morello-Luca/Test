// main.cpp — small demo / smoke driver for the agent engine.
//
// Submits a request, approves the plan, runs the workflow, and prints the
// markdown artifacts BEFORE AND AFTER the run so the user can see how the
// structured state evolves.

#include "core/AgentEngine.h"
#include "core/tools/IModelAdapter.h"
#include "core/tools/LocalFileTool.h"
#include "core/storage/InMemoryPlanRepository.h"
#include "existing/ModelLoader.h"
#include "core/models/DomainModels.h"

#include <iostream>
#include <memory>
#include <string>

int main() {
  using namespace agent_engine;
  // Build an engine with the existing (mock) model adapter + in-memory repo.
  // The mock loader returns a benign default stop response when its queue
  // is empty — i.e., the demo runs without a live model. Per spec §2, a
  // model stop without producing tool-call evidence is NOT proof that work
  // occurred; the verifier will reject it and recovery will block.
  existing::ModelLoader loader;
  std::unique_ptr<IModelAdapter> adapter(make_existing_model_adapter(loader));
  InMemoryPlanRepository repo;
  AgentEngine engine(std::move(adapter), repo);

  // Register a tool the agent can call.
  engine.tool_registry().register_tool(
      std::make_unique<LocalFileTool>("/demo_workspace"));

  // 1. Submit a straightforward request.
  UserRequest req{"wf_demo_1", "Add a hello.txt file to the workspace.",
                  "2026-10-15T00:00:00Z", {}};
  auto id = engine.submit_request(req);
  std::cout << "Submitted workflow: " << id
            << " (state=" << workflow_state_name(engine.state()) << ")\n";

  // 2. Inspect the draft plan BEFORE running.
  std::cout << "\n--- task_plan.md (DRAFT, before run) ---\n"
            << engine.render_task_plan_md() << "\n";

  // 3. Approve the plan.
  if (!engine.approve_plan()) {
    std::cerr << "approve_plan failed\n";
    return 1;
  }
  std::cout << "Plan approved (state="
            << workflow_state_name(engine.state()) << ")\n";

  // 4. Run to completion (or to whatever terminal state the workflow ends in).
  auto r = engine.run();
  std::cout << "\nRun result: " << static_cast<int>(r)
            << " (state=" << workflow_state_name(engine.state()) << ")\n";

  // 5. Render final artifacts AFTER running so the user sees the actual
  // post-execution structured state, not just the draft.
  std::cout << "\n--- task_plan.md (FINAL, after run) ---\n"
            << engine.render_task_plan_md() << "\n";
  std::cout << "\n--- findings.md ---\n" << engine.render_findings_md() << "\n";
  std::cout << "\n--- progress.md ---\n" << engine.render_progress_md() << "\n";

  // 6. Honest report of the outcome.
  std::cout << "\n--- outcome ---\n";
  switch (r) {
    case AgentEngine::RunResult::Completed:
      std::cout << "COMPLETED: every task Passed and every required "
                 << "acceptance criterion Passed.\n";
      break;
    case AgentEngine::RunResult::Blocked:
      std::cout << "BLOCKED: at least one task is Blocked. The workflow "
                 << "cannot complete without external intervention (e.g., "
                 << "plan revision).\n";
      break;
    case AgentEngine::RunResult::Failed:
      std::cout << "FAILED: at least one required task Failed.\n";
      break;
    case AgentEngine::RunResult::Cancelled:
      std::cout << "CANCELLED by user.\n";
      break;
    case AgentEngine::RunResult::Stalled:
      std::cout << "STALLED: no eligible task and not complete.\n";
      break;
  }
  return 0;
}
