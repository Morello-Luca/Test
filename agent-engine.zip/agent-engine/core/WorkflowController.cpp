// WorkflowController.cpp

#include "WorkflowController.h"

namespace agent_engine {

WorkflowController::WorkflowController(EventLog& log) : log_(log) {}

bool WorkflowController::transition_to(WorkflowState next,
                                          const std::string& reason) {
  if (state_ == next) return true;  // no-op transition is permitted
  if (!is_valid_transition(state_, next)) {
    log_.log(WorkflowEventKind::Note, workflow_state_name(state_),
             "rejected transition to " + std::string(workflow_state_name(next)) +
             ": " + reason);
    return false;
  }
  WorkflowState from = state_;
  state_ = next;
  log_.log(WorkflowEventKind::WorkflowStateChanged,
           workflow_state_name(state_),
           std::string(workflow_state_name(from)) + " -> " +
           workflow_state_name(next) + (reason.empty() ? "" : ": " + reason));
  return true;
}

bool WorkflowController::is_terminal() const {
  return state_ == WorkflowState::Completed ||
         state_ == WorkflowState::Cancelled ||
         state_ == WorkflowState::Failed;
}

}  // namespace agent_engine
