// ToolRegistry.h
//
// Spec §6: a registry that exposes ITool instances to the ToolDispatcher.

#ifndef AGENT_ENGINE_CORE_TOOLS_TOOL_REGISTRY_H
#define AGENT_ENGINE_CORE_TOOLS_TOOL_REGISTRY_H

#include "ITool.h"

#include <memory>
#include <string>
#include <unordered_map>
#include <vector>

namespace agent_engine {

class ToolRegistry {
 public:
  void register_tool(std::unique_ptr<ITool> tool);

  ITool* get(const std::string& name) const;
  std::vector<ITool*> all() const;

  /// JSON description of all tools (id + description + schema). Used by the
  /// AgentLoop to build the tools_json argument to IModelAdapter::infer().
  std::string describe_all_as_json() const;

 private:
  std::unordered_map<std::string, std::unique_ptr<ITool>> tools_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_TOOLS_TOOL_REGISTRY_H
