// MockTool.h
//
// Deterministic, scriptable tool for tests. Returns canned results based on
// the arguments (or a default if no scripted result matches).

#ifndef AGENT_ENGINE_CORE_TOOLS_MOCK_TOOL_H
#define AGENT_ENGINE_CORE_TOOLS_MOCK_TOOL_H

#include "ITool.h"

#include <functional>
#include <mutex>
#include <string>
#include <vector>

namespace agent_engine {

class MockTool : public ITool {
 public:
  using Handler = std::function<ToolResult(const ToolCall&)>;

  MockTool(std::string name, std::string description);

  void set_handler(Handler h);
  void script_result(const std::string& args_substr, ToolResult r);

  std::string name() const override { return name_; }
  std::string description() const override { return description_; }
  std::string input_schema_json() const override { return "{}"; }
  std::string validate_arguments(const std::string&) const override {
    return "";
  }
  ToolResult execute(const ToolCall& call) override;

 private:
  std::string name_;
  std::string description_;
  Handler handler_;
  std::vector<std::pair<std::string, ToolResult>> scripted_;
  mutable std::mutex mtx_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_TOOLS_MOCK_TOOL_H
