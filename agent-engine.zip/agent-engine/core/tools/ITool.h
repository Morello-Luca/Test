// ITool.h
//
// Spec §6: "Define a common ITool interface and a ToolRegistry. Tools must
// expose their name, description, input schema, and execution behavior."

#ifndef AGENT_ENGINE_CORE_TOOLS_I_TOOL_H
#define AGENT_ENGINE_CORE_TOOLS_I_TOOL_H

#include "core/models/ToolExecutionTypes.h"

#include <map>
#include <string>

namespace agent_engine {

class ITool {
 public:
  virtual ~ITool() = default;

  virtual std::string name() const = 0;
  virtual std::string description() const = 0;
  /// JSON schema describing the expected arguments object. Empty string
  /// means "no arguments". Per spec §6, validation is mandatory before
  /// execution.
  virtual std::string input_schema_json() const = 0;

  /// Validate args before execution. Must return a non-empty string error
  /// describing the first validation failure, or "" on success.
  virtual std::string validate_arguments(const std::string& arguments_json) const
      = 0;

  /// Execute the tool. Returns a structured ToolResult.
  /// Implementations MUST treat `arguments_json` as untrusted (spec §6).
  virtual ToolResult execute(const ToolCall& call) = 0;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_TOOLS_I_TOOL_H
