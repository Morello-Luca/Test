// ToolRegistry.cpp

#include "ToolRegistry.h"

#include <sstream>

namespace agent_engine {

void ToolRegistry::register_tool(std::unique_ptr<ITool> tool) {
  if (!tool) return;
  std::string n = tool->name();
  tools_[n] = std::move(tool);
}

ITool* ToolRegistry::get(const std::string& name) const {
  auto it = tools_.find(name);
  if (it == tools_.end()) return nullptr;
  return it->second.get();
}

std::vector<ITool*> ToolRegistry::all() const {
  std::vector<ITool*> out;
  out.reserve(tools_.size());
  for (const auto& [_, t] : tools_) out.push_back(t.get());
  return out;
}

std::string ToolRegistry::describe_all_as_json() const {
  // Minimal JSON; does not attempt to escape strings in schemas (schemas
  // are author-controlled, not user-controlled, so this is safe enough
  // for the initial implementation).
  std::ostringstream os;
  os << "[";
  bool first = true;
  for (const auto& [name, t] : tools_) {
    if (!first) os << ",";
    first = false;
    os << "{\"name\":\"" << name << "\","
       << "\"description\":\"" << t->description() << "\","
       << "\"input_schema\":" << (t->input_schema_json().empty() ?
                                  "{}" : t->input_schema_json()) << "}";
  }
  os << "]";
  return os.str();
}

}  // namespace agent_engine
