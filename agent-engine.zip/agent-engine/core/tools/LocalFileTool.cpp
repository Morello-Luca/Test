// LocalFileTool.cpp

#include "LocalFileTool.h"

#include <algorithm>
#include <cctype>
#include <sstream>

namespace agent_engine {

namespace {

// Very small JSON value parser. Only understands: string literals with
// \" and \\ escapes; objects with "key":"value" pairs. Sufficient for
// simulated tools where inputs are produced by our own mock model.
// Spec §6: treat inputs as untrusted; this parser fails loudly on
// malformed input.
bool parse_string(const std::string& s, size_t& i, std::string& out) {
  if (i >= s.size() || s[i] != '"') return false;
  ++i;
  std::string r;
  while (i < s.size() && s[i] != '"') {
    char c = s[i++];
    if (c == '\\' && i < s.size()) {
      char n = s[i++];
      if (n == '"') r += '"';
      else if (n == '\\') r += '\\';
      else if (n == 'n') r += '\n';
      else if (n == 't') r += '\t';
      else r += n;  // tolerant
    } else {
      r += c;
    }
  }
  if (i >= s.size() || s[i] != '"') return false;
  ++i;
  out = r;
  return true;
}

bool skip_ws(const std::string& s, size_t& i) {
  while (i < s.size() && std::isspace(static_cast<unsigned char>(s[i]))) ++i;
  return true;
}

bool parse_object(const std::string& s,
                   size_t& i,
                   std::map<std::string, std::string>& out) {
  skip_ws(s, i);
  if (i >= s.size() || s[i] != '{') return false;
  ++i;
  skip_ws(s, i);
  if (i < s.size() && s[i] == '}') { ++i; return true; }
  while (i < s.size()) {
    skip_ws(s, i);
    std::string key;
    if (!parse_string(s, i, key)) return false;
    skip_ws(s, i);
    if (i >= s.size() || s[i] != ':') return false;
    ++i;
    skip_ws(s, i);
    std::string val;
    if (!parse_string(s, i, val)) return false;
    out[key] = val;
    skip_ws(s, i);
    if (i < s.size() && s[i] == ',') { ++i; continue; }
    if (i < s.size() && s[i] == '}') { ++i; return true; }
    return false;
  }
  return false;
}

// (Removed unused `trim` helper; the parser does not need it.)

std::string normalize_path(const std::string& p) {
  // Resolve ".." and "." segments lexically; reject absolute traversal.
  std::vector<std::string> parts;
  std::istringstream is(p);
  std::string seg;
  while (std::getline(is, seg, '/')) {
    if (seg.empty() || seg == ".") continue;
    if (seg == "..") {
      if (parts.empty()) return "";  // traversal above root
      parts.pop_back();
    } else {
      parts.push_back(seg);
    }
  }
  std::string out;
  for (size_t i = 0; i < parts.size(); ++i) {
    if (i) out += "/";
    out += parts[i];
  }
  return out;
}

}  // namespace

LocalFileTool::LocalFileTool(std::string root_dir)
    : root_dir_(std::move(root_dir)) {}

std::string LocalFileTool::description() const {
  return "Read, write, list, stat, or check existence of files within "
         "the configured access boundary.";
}

std::string LocalFileTool::input_schema_json() const {
  return "{\"type\":\"object\",\"properties\":{"
         "\"op\":{\"type\":\"string\",\"enum\":[\"read\",\"write\",\"list\","
         "\"exists\",\"stat\"]},"
         "\"path\":{\"type\":\"string\"},"
         "\"content\":{\"type\":\"string\"}},"
         "\"required\":[\"op\",\"path\"]}";
}

std::string LocalFileTool::validate_arguments(
    const std::string& args_json) const {
  std::string op, path, content, err;
  if (!parse_args(args_json, op, path, content, err)) {
    return "malformed arguments: " + err;
  }
  if (op != "read" && op != "write" && op != "list" &&
      op != "exists" && op != "stat") {
    return "unknown op: " + op;
  }
  if (path.empty()) return "path is required";
  if (op == "write" && content.empty()) {
    return "write op requires non-empty content";
  }
  // Resolve and check access boundary.
  if (resolve_path(path).empty()) {
    return "path is outside access boundary";
  }
  return "";
}

ToolResult LocalFileTool::execute(const ToolCall& call) {
  ToolResult r;
  r.invocation_id = call.id;
  r.tool_name = name();
  // Spec §6: "Validate arguments before execution." Even when called
  // directly (bypassing ToolDispatcher), the tool re-validates defensively.
  if (auto verr = validate_arguments(call.arguments_json); !verr.empty()) {
    r.error = "invalid args: " + verr;
    return r;
  }
  auto args = call.arguments_json;
  std::string op, path, content, err;
  if (!parse_args(args, op, path, content, err)) {
    r.error = "malformed arguments: " + err;
    return r;
  }
  std::string abs = resolve_path(path);
  if (abs.empty()) {
    r.error = "path outside access boundary";
    return r;
  }
  std::lock_guard<std::mutex> lk(mtx_);
  if (op == "read") {
    auto it = vfs_.find(abs);
    if (it == vfs_.end()) {
      r.error = "not found: " + path;
      return r;
    }
    r.ok = true;
    r.output = it->second;
    r.metadata["size"] = std::to_string(it->second.size());
    // Spec §6: file contents are untrusted; flag if they look like prompt
    // injection (very cheap heuristic: contains "ignore previous").
    if (it->second.find("ignore previous") != std::string::npos ||
        it->second.find("SYSTEM:") != std::string::npos) {
      r.untrusted_content_flagged = true;
    }
    return r;
  }
  if (op == "write") {
    vfs_[abs] = content;
    r.ok = true;
    r.output = "wrote " + std::to_string(content.size()) + " bytes";
    return r;
  }
  if (op == "list") {
    std::ostringstream os;
    bool first = true;
    for (const auto& [p, _] : vfs_) {
      // Only list files under `abs`.
      if (p.rfind(abs, 0) == 0) {
        if (!first) os << "\n";
        first = false;
        os << p;
      }
    }
    r.ok = true;
    r.output = os.str();
    return r;
  }
  if (op == "exists") {
    r.ok = true;
    r.output = vfs_.count(abs) ? "true" : "false";
    r.metadata["exists"] = vfs_.count(abs) ? "true" : "false";
    return r;
  }
  if (op == "stat") {
    auto it = vfs_.find(abs);
    if (it == vfs_.end()) {
      r.error = "not found";
      return r;
    }
    r.ok = true;
    r.metadata["size"] = std::to_string(it->second.size());
    r.output = "{\"size\":" + std::to_string(it->second.size()) + "}";
    return r;
  }
  r.error = "unknown op: " + op;
  return r;
}

void LocalFileTool::seed_file(const std::string& relative_path,
                                const std::string& content) {
  std::string abs = resolve_path(relative_path);
  if (abs.empty()) return;
  std::lock_guard<std::mutex> lk(mtx_);
  vfs_[abs] = content;
}

std::string LocalFileTool::read_seeded(const std::string& relative_path)
    const {
  std::string abs = resolve_path(relative_path);
  if (abs.empty()) return "";
  std::lock_guard<std::mutex> lk(mtx_);
  auto it = vfs_.find(abs);
  return it == vfs_.end() ? "" : it->second;
}

std::string LocalFileTool::resolve_path(const std::string& user_path)
    const {
  // Treat root_dir_ as the absolute root. We do NOT do real fs; we work
  // against an in-memory map keyed by root_dir_ + "/" + normalized path.
  // Path traversal above root (e.g., "../..") is filtered out by
  // normalize_path returning "" — but legitimate inputs like "." or ""
  // legitimately resolve to the root itself.
  std::string norm = normalize_path(user_path);
  // normalize_path returns "" both for "traversal above root" and for
  // "." or empty. Distinguish them: a user path that contains ".." that
  // would escape the root is rejected. Otherwise the resolved path is
  // root_dir_ (+ optional relative segment).
  if (norm.empty()) {
    // Reject if user_path contained a ".." segment that escaped the root.
    // We approximate this by checking if the input contained ".." after
    // our normalization ran out of stack (i.e., user_path begins with ".."
    // or is exactly ".."/"../.."/etc).
    if (user_path.find("..") != std::string::npos) {
      // Could still be a legitimate nested ".." like "a/../b" which our
      // normalize_path handles correctly (collapses to "b"). Only reject
      // when user_path begins with ".." — that always escapes the root.
      std::string trimmed = user_path;
      size_t i = 0;
      while (i < trimmed.size() && std::isspace(
          static_cast<unsigned char>(trimmed[i]))) ++i;
      if (trimmed.compare(i, 2, "..") == 0) return "";
      // Otherwise treat as root reference.
    }
    // "." or "" -> root itself.
    return root_dir_;
  }
  // Disallow absolute paths starting with /; everything must be relative.
  return root_dir_ + "/" + norm;
}

bool LocalFileTool::parse_args(const std::string& args_json,
                                  std::string& op_out,
                                  std::string& path_out,
                                  std::string& content_out,
                                  std::string& err_out) {
  std::map<std::string, std::string> m;
  size_t i = 0;
  if (!parse_object(args_json, i, m)) {
    err_out = "not a JSON object";
    return false;
  }
  op_out = m.count("op") ? m["op"] : "";
  path_out = m.count("path") ? m["path"] : "";
  content_out = m.count("content") ? m["content"] : "";
  return true;
}

}  // namespace agent_engine
