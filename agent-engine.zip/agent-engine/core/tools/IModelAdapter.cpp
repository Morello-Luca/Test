// IModelAdapter.cpp
//
// Concrete adapters: MockModelAdapter (for tests / first run) and
// ExistingModelAdapter (wraps the pre-existing ModelLoader).

#include "IModelAdapter.h"

#include "existing/ModelLoader.h"

#include <stdexcept>

namespace agent_engine {

// ---------------------------------------------------------------------------
// MockModelAdapter
//
// Deterministic, scriptable adapter. Tests push scripted responses and the
// adapter hands them out FIFO. If the queue runs dry, it returns a stop
// response so the agent loop can still terminate cleanly.
// ---------------------------------------------------------------------------
class MockModelAdapter : public IModelAdapter {
 public:
  void script(AdapterResponse r) { scripted_.push_back(std::move(r)); }

  AdapterResponse infer(const std::vector<AdapterMessage>& /*messages*/,
                         const std::string& /*tools_json*/) override {
    if (!scripted_.empty()) {
      AdapterResponse r = std::move(scripted_.front());
      scripted_.erase(scripted_.begin());
      return r;
    }
    AdapterResponse r;
    r.content = "[mock-model] no scripted response; returning stop.";
    r.finish_reason = "stop";
    return r;
  }

 private:
  std::vector<AdapterResponse> scripted_;
};

// ---------------------------------------------------------------------------
// ExistingModelAdapter
//
// Thin wrapper around the existing::ModelLoader. Translates the core
// AdapterMessage format to/from the existing project's LoaderMessage format,
// satisfying spec section 11's requirement that the agent runtime does not
// see provider-specific types.
// ---------------------------------------------------------------------------
class ExistingModelAdapter : public IModelAdapter {
 public:
  explicit ExistingModelAdapter(existing::ModelLoader& loader)
      : loader_(loader) {}

  AdapterResponse infer(const std::vector<AdapterMessage>& messages,
                         const std::string& tools_json) override {
    std::vector<existing::LoaderMessage> translated;
    translated.reserve(messages.size());
    for (const auto& m : messages) {
      existing::LoaderMessage lm;
      lm.role = m.role;
      lm.content = m.content;
      translated.push_back(std::move(lm));
    }
    auto raw = loader_.infer(translated, tools_json);
    AdapterResponse out;
    out.content = std::move(raw.content);
    out.finish_reason = std::move(raw.finish_reason);
    out.tool_calls.reserve(raw.tool_calls.size());
    for (auto& tc : raw.tool_calls) {
      AdapterToolCall atc;
      atc.id = std::move(tc.id);
      atc.name = std::move(tc.name);
      atc.arguments_json = std::move(tc.arguments_json);
      out.tool_calls.push_back(std::move(atc));
    }
    return out;
  }

 private:
  existing::ModelLoader& loader_;
};

/// Public factory used by AgentEngine to obtain a mock adapter.
IModelAdapter* make_mock_model_adapter() { return new MockModelAdapter(); }

/// Public factory used by AgentEngine to wrap the existing ModelLoader.
IModelAdapter* make_existing_model_adapter(existing::ModelLoader& loader) {
  return new ExistingModelAdapter(loader);
}

}  // namespace agent_engine
