// LocalFileTool.h
//
// Spec §2.1 + §6: ONE cohesive tool handling all filesystem operations:
// read, write, list, stat, exists. Path validation + access boundaries
// are enforced here. A `root_dir_` constrains where the tool may operate.
//
// To keep the initial implementation safe and mockable, this tool operates
// against an in-memory virtual filesystem (map<path, bytes>). Real fs access
// would swap the VFS implementation while keeping the ITool contract intact.

#ifndef AGENT_ENGINE_CORE_TOOLS_LOCAL_FILE_TOOL_H
#define AGENT_ENGINE_CORE_TOOLS_LOCAL_FILE_TOOL_H

#include "ITool.h"

#include <map>
#include <mutex>
#include <string>

namespace agent_engine {

class LocalFileTool : public ITool {
 public:
  /// `root_dir` is the configured access boundary; absolute paths must be
  /// inside it. Relative paths are resolved against it.
  explicit LocalFileTool(std::string root_dir);

  std::string name() const override { return "local_file"; }
  std::string description() const override;
  std::string input_schema_json() const override;
  std::string validate_arguments(const std::string& args_json) const override;
  ToolResult execute(const ToolCall& call) override;

  // Test hook: inject a file into the VFS.
  void seed_file(const std::string& relative_path, const std::string& content);

  // Test hook: read a file directly from the VFS.
  std::string read_seeded(const std::string& relative_path) const;

 private:
  // Resolve a user-supplied path relative to root_dir_; returns absolute or
  // empty string on failure (path traversal attempt, outside boundary).
  std::string resolve_path(const std::string& user_path) const;

  // Extract "op" and "path" fields from arguments_json (very small parser;
  // spec §6 says treat inputs as untrusted). Returns false on parse failure.
  static bool parse_args(const std::string& args_json,
                          std::string& op_out,
                          std::string& path_out,
                          std::string& content_out,
                          std::string& err_out);

  std::string root_dir_;
  mutable std::mutex mtx_;
  std::map<std::string, std::string> vfs_;
};

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_TOOLS_LOCAL_FILE_TOOL_H
