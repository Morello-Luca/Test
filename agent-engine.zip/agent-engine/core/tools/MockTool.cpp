// MockTool.cpp

#include "MockTool.h"

namespace agent_engine {

MockTool::MockTool(std::string name, std::string description)
    : name_(std::move(name)), description_(std::move(description)) {}

void MockTool::set_handler(Handler h) {
  std::lock_guard<std::mutex> lk(mtx_);
  handler_ = std::move(h);
}

void MockTool::script_result(const std::string& args_substr, ToolResult r) {
  std::lock_guard<std::mutex> lk(mtx_);
  scripted_.emplace_back(args_substr, std::move(r));
}

ToolResult MockTool::execute(const ToolCall& call) {
  std::lock_guard<std::mutex> lk(mtx_);
  // Scripted results checked first by substring match on arguments.
  for (auto& [substr, r] : scripted_) {
    if (!substr.empty() && call.arguments_json.find(substr) != std::string::npos) {
      ToolResult out = r;
      out.invocation_id = call.id;
      return out;
    }
  }
  if (handler_) {
    auto r = handler_(call);
    r.invocation_id = call.id;
    return r;
  }
  ToolResult r;
  r.invocation_id = call.id;
  r.tool_name = name_;
  r.ok = true;
  r.output = "[mock " + name_ + "] default ok response";
  return r;
}

}  // namespace agent_engine
