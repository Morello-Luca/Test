// IModelAdapter.h
//
// Narrow boundary between the agent runtime and whatever LLM implementation
// exists in the project. Per spec section 11: "The agent runtime must not
// depend on provider-specific response structures." Everything in core/
// depends only on IModelAdapter, never on existing::ModelLoader.

#ifndef AGENT_ENGINE_CORE_TOOLS_I_MODEL_ADAPTER_H
#define AGENT_ENGINE_CORE_TOOLS_I_MODEL_ADAPTER_H

#include <string>
#include <vector>

namespace agent_engine {

/// Role + content. Mirrors existing::LoaderMessage but owned by core/ so the
/// adapter is free to translate from any provider format.
struct AdapterMessage {
  std::string role;
  std::string content;
};

struct AdapterToolCall {
  std::string id;
  std::string name;
  std::string arguments_json;
};

struct AdapterResponse {
  std::string content;
  std::vector<AdapterToolCall> tool_calls;
  std::string finish_reason;  // "stop" | "tool_use" | "length" | "error"
};

/// Provider-agnostic chat + tool-calling interface. Implementations translate
/// to/from whatever backing model exists. The default mock implementation is
/// MockModelAdapter (see IModelAdapter.cpp), and ExistingModelAdapter wraps
/// the pre-existing ModelLoader.
class IModelAdapter {
 public:
  virtual ~IModelAdapter() = default;

  /// Run one inference turn. `tools_json` is a JSON description of available
  /// tools; may be empty if no tools are exposed this turn.
  virtual AdapterResponse infer(const std::vector<AdapterMessage>& messages,
                                 const std::string& tools_json) = 0;
};

// ---- Factory declarations (defined in IModelAdapter.cpp) ----------------

namespace existing { class ModelLoader; }

/// Factory: returns a deterministic, scriptable mock adapter (no backing model).
IModelAdapter* make_mock_model_adapter();

/// Factory: wraps the pre-existing `existing::ModelLoader` so the agent
/// runtime never depends on provider-specific types.
IModelAdapter* make_existing_model_adapter(existing::ModelLoader& loader);

}  // namespace agent_engine

#endif  // AGENT_ENGINE_CORE_TOOLS_I_MODEL_ADAPTER_H
